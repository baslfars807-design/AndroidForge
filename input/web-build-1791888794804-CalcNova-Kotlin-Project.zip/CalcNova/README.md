# CalcNova — Native Kotlin Android Calculator

A real Android project (not a web wrapper), written in Kotlin + Jetpack Compose / Material 3. Works offline and supports Android 6.0+ (minSdk 23).

## Features
- Arithmetic: addition, subtraction, multiplication, division, percentage, parentheses, powers, unary sign, decimals.
- Scientific functions: sin, cos, tan, sqrt, ln, log10, abs, floor, ceil, asin, acos, atan, constants π and e, factorial via `fact(number)`.
- DEG/RAD toggle, animated result updates and spring-like button feedback.
- Light/dark mode saved locally; calculation history saved locally and can be recalled/cleared.
- No ads, accounts, network permissions, or placeholder buttons.

## Build
Open this project in Android Studio or import it into a compatible cloud Android build workflow. Use JDK 17 and Android SDK 35. Gradle wrapper is not bundled; the build environment can generate/use its compatible wrapper.

## Notes
This source archive has not been built or executed in this environment. Test a debug APK before distribution. For scientific functions, enter function calls with parentheses, e.g. `sin(30)`, `sqrt(81)`, `fact(5)`. `%` is implemented as percentage (divide by 100) in the expression parser.
