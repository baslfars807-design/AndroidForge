package com.max.calcnova

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Backspace
import androidx.compose.material.icons.rounded.Calculate
import androidx.compose.material.icons.rounded.DarkMode
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.LightMode
import androidx.compose.material.icons.rounded.MoreHoriz
import androidx.compose.material.icons.rounded.SwapHoriz
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import java.math.BigDecimal
import java.math.MathContext
import java.math.RoundingMode
import kotlin.math.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { CalcNovaApp() }
    }
}

private data class CalcRecord(val expression: String, val result: String)

@Composable
private fun CalcNovaApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val prefs = remember { context.getSharedPreferences("calcnova", 0) }
    var dark by remember { mutableStateOf(prefs.getBoolean("dark", false)) }
    var expression by remember { mutableStateOf("") }
    var result by remember { mutableStateOf("0") }
    var error by remember { mutableStateOf("") }
    var degrees by remember { mutableStateOf(prefs.getBoolean("degrees", true)) }
    var historyOpen by remember { mutableStateOf(false) }
    var history by remember {
        mutableStateOf(runCatching {
            val a = JSONArray(prefs.getString("history", "[]"))
            (0 until a.length()).map { CalcRecord(a.getJSONObject(it).getString("e"), a.getJSONObject(it).getString("r")) }
        }.getOrDefault(emptyList()))
    }
    val bg by animateColorAsState(if (dark) Color(0xFF101218) else Color(0xFFF6F7FB), spring(stiffness = 380f), label = "bg")
    val fg = if (dark) Color(0xFFF3F3F7) else Color(0xFF191B20)
    val muted = if (dark) Color(0xFFA6AAB5) else Color(0xFF6B707A)
    val panel = if (dark) Color(0xFF1B1E27) else Color.White
    val op = if (dark) Color(0xFF293142) else Color(0xFFE8ECF7)
    val accent = if (dark) Color(0xFFB8C7FF) else Color(0xFF435DCE)

    fun persistHistory() {
        val arr = JSONArray()
        history.take(60).forEach { item -> arr.put(org.json.JSONObject().put("e", item.expression).put("r", item.result)) }
        prefs.edit().putString("history", arr.toString()).apply()
    }
    fun evaluate() {
        if (expression.isBlank()) return
        try {
            val out = CalculatorEngine(degrees).evaluate(expression)
            result = formatNumber(out)
            error = ""
            history = (listOf(CalcRecord(expression, result)) + history).distinctBy { it.expression to it.result }.take(60)
            persistHistory()
            expression = result
        } catch (_: Exception) { error = "تأكد من العملية الحسابية" }
    }
    BackHandler(historyOpen) { historyOpen = false }

    MaterialTheme(colorScheme = if (dark) darkColorScheme(primary = accent, background = bg, surface = panel) else lightColorScheme(primary = accent, background = bg, surface = panel)) {
        Surface(modifier = Modifier.fillMaxSize(), color = bg) {
            Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(horizontal = 18.dp)) {
                Row(Modifier.fillMaxWidth().padding(top = 10.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Box(Modifier.size(42.dp).background(accent, RoundedCornerShape(15.dp)), contentAlignment = Alignment.Center) { Icon(Icons.Rounded.Calculate, null, tint = if (dark) Color(0xFF111522) else Color.White) }
                        Column { Text("CalcNova", color = fg, fontSize = 20.sp, fontWeight = FontWeight.Bold); Text("حاسبة ذكية", color = muted, fontSize = 12.sp) }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        SmallAction({ historyOpen = !historyOpen }, panel, fg) { Icon(Icons.Rounded.History, "السجل") }
                        SmallAction({ dark = !dark; prefs.edit().putBoolean("dark", dark).apply() }, panel, fg) { Icon(if (dark) Icons.Rounded.LightMode else Icons.Rounded.DarkMode, "تبديل الوضع") }
                    }
                }

                if (historyOpen) {
                    Row(Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("سجل العمليات", color = fg, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                        TextButton(onClick = { history = emptyList(); persistHistory() }) { Text("مسح السجل") }
                    }
                    if (history.isEmpty()) Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) { Text("لا توجد عمليات محفوظة بعد", color = muted) }
                    else LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        items(history) { item ->
                            Column(Modifier.fillMaxWidth().background(panel, RoundedCornerShape(20.dp)).clickable { expression = item.expression; result = item.result; error = ""; historyOpen = false }.padding(16.dp)) {
                                Text(item.expression, color = muted, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(item.result, color = fg, fontSize = 23.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.End)
                            }
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                } else {
                    Spacer(Modifier.height(12.dp))
                    Column(Modifier.fillMaxWidth().weight(0.9f).background(panel, RoundedCornerShape(30.dp)).padding(horizontal = 22.dp, vertical = 20.dp), verticalArrangement = Arrangement.Bottom, horizontalAlignment = Alignment.End) {
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("الحساب", color = muted, fontSize = 13.sp)
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.clickable { degrees = !degrees; prefs.edit().putBoolean("degrees", degrees).apply() }.background(op, CircleShape).padding(horizontal = 11.dp, vertical = 7.dp)) {
                                Icon(Icons.Rounded.SwapHoriz, null, tint = accent, modifier = Modifier.size(16.dp)); Spacer(Modifier.width(5.dp)); Text(if (degrees) "DEG" else "RAD", color = fg, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                            }
                        }
                        Spacer(Modifier.height(18.dp))
                        Text(expression.ifBlank { "0" }, color = muted, fontSize = 25.sp, textAlign = TextAlign.End, maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.fillMaxWidth())
                        Spacer(Modifier.height(8.dp))
                        AnimatedContent(targetState = result, label = "result") { value -> Text(value, color = fg, fontSize = if (value.length > 12) 32.sp else 42.sp, fontWeight = FontWeight.Medium, textAlign = TextAlign.End, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.fillMaxWidth()) }
                        if (error.isNotEmpty()) { Spacer(Modifier.height(6.dp)); Text(error, color = Color(0xFFE35D6A), fontSize = 13.sp) }
                    }
                    Spacer(Modifier.height(18.dp))
                    val rows = listOf(
                        listOf("AC", "( )", "%", "÷"),
                        listOf("sin", "cos", "tan", "×"),
                        listOf("7", "8", "9", "−"),
                        listOf("4", "5", "6", "+"),
                        listOf("1", "2", "3", "⌫"),
                        listOf("±", "0", ".", "=")
                    )
                    Column(Modifier.weight(1.55f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        rows.forEachIndexed { ri, row ->
                            Row(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                row.forEachIndexed { ci, key ->
                                    val isEquals = key == "="
                                    val isAction = key in listOf("AC", "( )", "%", "÷", "×", "−", "+", "⌫", "±", "sin", "cos", "tan")
                                    val color = when { isEquals -> accent; isAction -> op; else -> panel }
                                    val textColor = if (isEquals) Color.White else if (isAction && key in listOf("÷", "×", "−", "+", "sin", "cos", "tan")) accent else fg
                                    CalcKey(key, color, textColor, Modifier.weight(1f).fillMaxHeight()) {
                                        error = ""
                                        when (key) {
                                            "AC" -> { expression = ""; result = "0" }
                                            "⌫" -> if (expression.isNotEmpty()) expression = expression.dropLast(1)
                                            "=" -> evaluate()
                                            "( )" -> { val opens = expression.count { it == '(' }; val closes = expression.count { it == ')' }; expression += if (opens > closes) ")" else "(" }
                                            "±" -> { expression = if (expression.startsWith("-") && expression.count { it == '(' } == 0) expression.drop(1) else if (expression.isBlank()) "-" else "(-$expression)" }
                                            "sin", "cos", "tan" -> expression += "$key("
                                            "÷" -> expression += "/"
                                            "×" -> expression += "*"
                                            "−" -> expression += "-"
                                            "%" -> expression += "%"
                                            else -> expression += key
                                        }
                                    }
                                }
                            }
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    Row(Modifier.fillMaxWidth().padding(bottom = 8.dp), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.MoreHoriz, null, tint = muted, modifier = Modifier.size(18.dp)); Spacer(Modifier.width(6.dp)); Text("أساسي • علمي • بدون إنترنت", color = muted, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun SmallAction(onClick: () -> Unit, color: Color, tint: Color, content: @Composable () -> Unit) {
    Box(Modifier.size(42.dp).background(color, CircleShape).clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onClick), contentAlignment = Alignment.Center) { CompositionLocalProvider(LocalContentColor provides tint) { content() } }
}

@Composable
private fun CalcKey(label: String, color: Color, textColor: Color, modifier: Modifier, onClick: () -> Unit) {
    var pressed by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(if (pressed) 0.92f else 1f, spring(dampingRatio = 0.48f, stiffness = 520f), label = "keyScale")
    Surface(modifier = modifier.scale(scale).clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { pressed = true; onClick(); pressed = false }, color = color, shape = RoundedCornerShape(23.dp), tonalElevation = if (label == "=") 3.dp else 0.dp) {
        Box(contentAlignment = Alignment.Center) { Text(label, color = textColor, fontSize = if (label.length > 2) 15.sp else 23.sp, fontWeight = if (label == "=" || label in listOf("AC", "÷", "×", "−", "+")) FontWeight.SemiBold else FontWeight.Medium) }
    }
}

private fun formatNumber(value: Double): String {
    if (!value.isFinite()) throw ArithmeticException("Non-finite result")
    if (abs(value) < 1e-12) return "0"
    val bd = BigDecimal.valueOf(value).round(MathContext(12, RoundingMode.HALF_UP)).stripTrailingZeros()
    return bd.toPlainString().takeIf { it.length <= 18 } ?: String.format(java.util.Locale.US, "%.8g", value)
}

/** Recursive-descent expression parser: + - * / %, parentheses, unary signs, and trig/sqrt/log constants. */
private class CalculatorEngine(private val degrees: Boolean) {
    private lateinit var s: String
    private var p = 0
    fun evaluate(input: String): Double {
        s = input.replace("×", "*").replace("÷", "/").replace("−", "-").replace("π", "pi").replace("×10^", "*10^").replace("²", "^2").replace("³", "^3").replace("√", "sqrt")
        p = 0
        val value = parseExpression()
        skip()
        if (p != s.length || !value.isFinite()) throw IllegalArgumentException("Invalid expression")
        return value
    }
    private fun skip() { while (p < s.length && s[p].isWhitespace()) p++ }
    private fun eat(c: Char): Boolean { skip(); if (p < s.length && s[p] == c) { p++; return true }; return false }
    private fun parseExpression(): Double { var x = parseTerm(); while (true) { x = when { eat('+') -> x + parseTerm(); eat('-') -> x - parseTerm(); else -> return x } } }
    private fun parseTerm(): Double { var x = parsePower(); while (true) { x = when { eat('*') -> x * parsePower(); eat('/') -> { val d = parsePower(); if (d == 0.0) throw ArithmeticException("Divide by zero"); x / d }; eat('%') -> x % 100.0; else -> return x } } }
    private fun parsePower(): Double { var x = parseUnary(); if (eat('^')) x = x.pow(parsePower()); return x }
    private fun parseUnary(): Double { if (eat('+')) return parseUnary(); if (eat('-')) return -parseUnary(); return parseAtom() }
    private fun parseAtom(): Double {
        skip()
        if (eat('(')) { val x = parseExpression(); if (!eat(')')) throw IllegalArgumentException("Missing )"); return x }
        if (p >= s.length) throw IllegalArgumentException("Missing value")
        if (s[p].isDigit() || s[p] == '.') {
            val start = p; while (p < s.length && (s[p].isDigit() || s[p] == '.')) p++
            if (p < s.length && (s[p] == 'e' || s[p] == 'E')) { p++; if (p < s.length && (s[p] == '+' || s[p] == '-')) p++; while (p < s.length && s[p].isDigit()) p++ }
            return s.substring(start, p).toDouble()
        }
        if (s[p].isLetter()) {
            val start = p; while (p < s.length && s[p].isLetter()) p++; val name = s.substring(start, p).lowercase()
            if (name == "pi") return Math.PI
            if (name == "e") return Math.E
            if (!eat('(')) throw IllegalArgumentException("Function needs parentheses")
            val v = parseExpression(); if (!eat(')')) throw IllegalArgumentException("Missing )")
            val a = if (degrees) Math.toRadians(v) else v
            return when (name) {
                "sin" -> sin(a); "cos" -> cos(a); "tan" -> tan(a)
                "sqrt" -> sqrt(v); "ln" -> ln(v); "log" -> log10(v)
                "abs" -> abs(v); "floor" -> floor(v); "ceil" -> ceil(v)
                "asin" -> { val r = asin(v); if (degrees) Math.toDegrees(r) else r }
                "acos" -> { val r = acos(v); if (degrees) Math.toDegrees(r) else r }
                "atan" -> { val r = atan(v); if (degrees) Math.toDegrees(r) else r }
                "fact" -> { if (v < 0 || v > 170 || v % 1.0 != 0.0) throw ArithmeticException("Invalid factorial"); (2..v.toInt()).fold(1.0) { acc, n -> acc * n } }
                else -> throw IllegalArgumentException("Unknown function")
            }
        }
        throw IllegalArgumentException("Unexpected character")
    }
}
