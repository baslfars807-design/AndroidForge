package com.example.ui.screens

import android.content.Intent
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.outlined.VolumeUp
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ChecklistItem
import com.example.model.Note
import com.example.model.ThemeMode
import com.example.model.UserPreferences
import com.example.ui.theme.NoteColorPalette
import com.example.ui.theme.getNoteCardColor
import com.example.viewmodel.NotesViewModel
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditorScreen(
    noteId: Long?,
    viewModel: NotesViewModel,
    userPreferences: UserPreferences,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val categories by viewModel.categories.collectAsState()

    var currentNoteId by remember { mutableStateOf(noteId ?: 0L) }
    var title by remember { mutableStateOf("") }
    var content by remember { mutableStateOf("") }
    var checklistItems by remember { mutableStateOf(listOf<ChecklistItem>()) }
    var selectedColorHex by remember { mutableStateOf("#00000000") }
    var selectedCategoryId by remember { mutableStateOf<Long?>(null) }
    var isPinned by remember { mutableStateOf(false) }
    var isFavorite by remember { mutableStateOf(false) }
    var isArchived by remember { mutableStateOf(false) }
    var isLoaded by remember { mutableStateOf(false) }

    var newChecklistInput by remember { mutableStateOf("") }
    var showColorPickerSheet by remember { mutableStateOf(false) }
    var showStatsDialog by remember { mutableStateOf(false) }
    var saveStatusText by remember { mutableStateOf("محفوظ / Saved") }

    // Live word and character stats
    val wordCount = remember(title, content) {
        val count1 = title.split("\\s+".toRegex()).count { it.isNotBlank() }
        val count2 = content.split("\\s+".toRegex()).count { it.isNotBlank() }
        count1 + count2
    }
    val charCount = remember(title, content) { title.length + content.length }
    val readingTimeMinutes = remember(wordCount) { maxOf(1, (wordCount + 150) / 200) }

    // Load initial note data if editing
    LaunchedEffect(noteId) {
        if (noteId != null && noteId > 0) {
            val note = viewModel.getNote(noteId)
            if (note != null) {
                currentNoteId = note.id
                title = note.title
                content = note.content
                checklistItems = viewModel.parseChecklist(note.checklistJson)
                selectedColorHex = note.colorHex
                selectedCategoryId = note.categoryId
                isPinned = note.isPinned
                isFavorite = note.isFavorite
                isArchived = note.isArchived
            }
        }
        isLoaded = true
    }

    fun triggerAutoSave() {
        if (!isLoaded) return
        if (title.isBlank() && content.isBlank() && checklistItems.isEmpty() && currentNoteId == 0L) return

        saveStatusText = "جاري الحفظ… / Saving…"
        val noteToSave = Note(
            id = currentNoteId,
            title = title,
            content = content,
            checklistJson = viewModel.serializeChecklist(checklistItems),
            colorHex = selectedColorHex,
            categoryId = selectedCategoryId,
            isPinned = isPinned,
            isFavorite = isFavorite,
            isArchived = isArchived
        )

        viewModel.autoSaveNoteDebounced(noteToSave) { newId ->
            if (currentNoteId == 0L) {
                currentNoteId = newId
            }
            saveStatusText = "تم الحفظ / Saved"
        }
    }

    // Trigger save on back button
    BackHandler {
        if (isLoaded && (title.isNotBlank() || content.isNotBlank() || checklistItems.isNotEmpty())) {
            val noteToSave = Note(
                id = currentNoteId,
                title = title,
                content = content,
                checklistJson = viewModel.serializeChecklist(checklistItems),
                colorHex = selectedColorHex,
                categoryId = selectedCategoryId,
                isPinned = isPinned,
                isFavorite = isFavorite,
                isArchived = isArchived
            )
            viewModel.saveNote(noteToSave)
        }
        viewModel.stopSpeech()
        onBack()
    }

    val isDark = when (userPreferences.themeMode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }
    val defaultSurface = MaterialTheme.colorScheme.background
    val editorBackgroundColor = getNoteCardColor(selectedColorHex, isDark, defaultSurface)

    Scaffold(
        containerColor = editorBackgroundColor,
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = saveStatusText,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = "$wordCount كلمة • $charCount حرف",
                            style = MaterialTheme.typography.labelSmall,
                            fontSize = 10.sp,
                            color = MaterialTheme.colorScheme.outline
                        )
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = {
                            if (isLoaded && (title.isNotBlank() || content.isNotBlank() || checklistItems.isNotEmpty())) {
                                val noteToSave = Note(
                                    id = currentNoteId,
                                    title = title,
                                    content = content,
                                    checklistJson = viewModel.serializeChecklist(checklistItems),
                                    colorHex = selectedColorHex,
                                    categoryId = selectedCategoryId,
                                    isPinned = isPinned,
                                    isFavorite = isFavorite,
                                    isArchived = isArchived
                                )
                                viewModel.saveNote(noteToSave)
                            }
                            viewModel.stopSpeech()
                            onBack()
                        },
                        modifier = Modifier.testTag("editor_back_button")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    // Offline Device Text-To-Speech Read Aloud Action
                    IconButton(
                        onClick = {
                            val textToRead = "$title. $content"
                            if (textToRead.isNotBlank()) {
                                viewModel.readNoteAloud(textToRead)
                            }
                        },
                        modifier = Modifier.testTag("tts_read_aloud_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Outlined.VolumeUp,
                            contentDescription = "Read Note Aloud",
                            tint = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    // Toggle Pin
                    IconButton(
                        onClick = {
                            isPinned = !isPinned
                            triggerAutoSave()
                        },
                        modifier = Modifier.testTag("editor_pin_button")
                    ) {
                        Icon(
                            imageVector = if (isPinned) Icons.Filled.PushPin else Icons.Outlined.PushPin,
                            contentDescription = "Pin Note",
                            tint = if (isPinned) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    // Toggle Favorite
                    IconButton(
                        onClick = {
                            isFavorite = !isFavorite
                            triggerAutoSave()
                        },
                        modifier = Modifier.testTag("editor_favorite_button")
                    ) {
                        Icon(
                            imageVector = if (isFavorite) Icons.Filled.Star else Icons.Outlined.StarBorder,
                            contentDescription = "Favorite Note",
                            tint = if (isFavorite) Color(0xFFF59E0B) else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    // Export Note as PDF Document
                    IconButton(
                        onClick = {
                            val currentNote = Note(
                                id = currentNoteId,
                                title = title,
                                content = content,
                                checklistJson = viewModel.serializeChecklist(checklistItems),
                                colorHex = selectedColorHex,
                                categoryId = selectedCategoryId,
                                isPinned = isPinned,
                                isFavorite = isFavorite,
                                isArchived = isArchived
                            )
                            val cat = categories.firstOrNull { it.id == selectedCategoryId }
                            viewModel.exportNoteAsPdf(context, currentNote, cat, checklistItems)
                        },
                        modifier = Modifier.testTag("editor_export_pdf_button")
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.PictureAsPdf,
                            contentDescription = "Export Note as PDF",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }

                    // Share Note Text
                    IconButton(
                        onClick = {
                            val formattedText = viewModel.formatNoteAsText(
                                Note(
                                    id = currentNoteId,
                                    title = title,
                                    content = content,
                                    checklistJson = viewModel.serializeChecklist(checklistItems)
                                )
                            )
                            val sendIntent = Intent().apply {
                                action = Intent.ACTION_SEND
                                putExtra(Intent.EXTRA_TEXT, formattedText)
                                type = "text/plain"
                            }
                            context.startActivity(Intent.createChooser(sendIntent, "Share Note"))
                        },
                        modifier = Modifier.testTag("editor_share_button")
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Share,
                            contentDescription = "Share Note",
                            tint = MaterialTheme.colorScheme.onSurface
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = editorBackgroundColor
                )
            )
        },
        bottomBar = {
            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                tonalElevation = 2.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceAround,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 6.dp)
                ) {
                    // Color Picker Trigger
                    IconButton(
                        onClick = { showColorPickerSheet = true },
                        modifier = Modifier.testTag("open_color_picker_button")
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Palette,
                            contentDescription = "Change Color",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    // Category Tag Trigger
                    var showCategoryMenu by remember { mutableStateOf(false) }
                    Box {
                        IconButton(
                            onClick = { showCategoryMenu = true },
                            modifier = Modifier.testTag("open_category_menu_button")
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.Label,
                                contentDescription = "Assign Category",
                                tint = if (selectedCategoryId != null) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        DropdownMenu(
                            expanded = showCategoryMenu,
                            onDismissRequest = { showCategoryMenu = false }
                        ) {
                            DropdownMenuItem(
                                text = { Text("بدون تصنيف / None") },
                                onClick = {
                                    selectedCategoryId = null
                                    triggerAutoSave()
                                    showCategoryMenu = false
                                }
                            )
                            categories.forEach { cat ->
                                DropdownMenuItem(
                                    text = { Text(cat.name) },
                                    onClick = {
                                        selectedCategoryId = cat.id
                                        triggerAutoSave()
                                        showCategoryMenu = false
                                    }
                                )
                            }
                        }
                    }

                    // Insert Current Timestamp Action
                    IconButton(
                        onClick = {
                            val timeFormat = SimpleDateFormat("EEEE, d MMMM yyyy - hh:mm a", Locale.getDefault())
                            val timestampStr = timeFormat.format(Date())
                            content = if (content.isBlank()) {
                                "📅 $timestampStr\n"
                            } else {
                                "$content\n\n📅 $timestampStr\n"
                            }
                            triggerAutoSave()
                        },
                        modifier = Modifier.testTag("insert_timestamp_button")
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.AccessTime,
                            contentDescription = "Insert Timestamp",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    // Note Statistics Dialog Trigger
                    IconButton(
                        onClick = { showStatsDialog = true },
                        modifier = Modifier.testTag("note_stats_button")
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Analytics,
                            contentDescription = "Note Statistics",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    // Archive Action
                    IconButton(
                        onClick = {
                            isArchived = !isArchived
                            triggerAutoSave()
                        },
                        modifier = Modifier.testTag("editor_archive_button")
                    ) {
                        Icon(
                            imageVector = if (isArchived) Icons.Filled.Archive else Icons.Outlined.Archive,
                            contentDescription = "Archive Note",
                            tint = if (isArchived) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    // Delete to Trash Action
                    IconButton(
                        onClick = {
                            if (currentNoteId > 0) {
                                viewModel.deleteNote(
                                    Note(
                                        id = currentNoteId,
                                        title = title,
                                        content = content,
                                        checklistJson = viewModel.serializeChecklist(checklistItems)
                                    )
                                )
                            }
                            onBack()
                        },
                        modifier = Modifier.testTag("editor_delete_button")
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Delete,
                            contentDescription = "Move to Trash",
                            tint = MaterialTheme.colorScheme.error
                        )
                    }
                }
            }
        },
        modifier = modifier.fillMaxSize()
    ) { innerPadding ->
        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Category Chip Display (if assigned)
            item {
                val assignedCat = categories.firstOrNull { it.id == selectedCategoryId }
                if (assignedCat != null) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f),
                        modifier = Modifier.padding(bottom = 12.dp)
                    ) {
                        Text(
                            text = "🏷️ ${assignedCat.name}",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onPrimaryContainer,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }
                }
            }

            // Note Title Input
            item {
                TextField(
                    value = title,
                    onValueChange = {
                        title = it
                        triggerAutoSave()
                    },
                    placeholder = {
                        Text(
                            text = "عنوان الملاحظة / Title",
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontSize = (22 * userPreferences.fontSize.scale).sp,
                                fontWeight = FontWeight.Bold
                            ),
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
                        )
                    },
                    textStyle = MaterialTheme.typography.titleLarge.copy(
                        fontSize = (22 * userPreferences.fontSize.scale).sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    ),
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = Color.Transparent,
                        unfocusedContainerColor = Color.Transparent,
                        disabledContainerColor = Color.Transparent,
                        focusedIndicatorColor = Color.Transparent,
                        unfocusedIndicatorColor = Color.Transparent
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("note_title_input")
                )
            }

            // Note Content Input
            item {
                TextField(
                    value = content,
                    onValueChange = {
                        content = it
                        triggerAutoSave()
                    },
                    placeholder = {
                        Text(
                            text = "ابدأ بكتابة المحتوى أو الأفكار هنا… / Note content…",
                            style = MaterialTheme.typography.bodyLarge.copy(
                                fontSize = (16 * userPreferences.fontSize.scale).sp
                            ),
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
                        )
                    },
                    textStyle = MaterialTheme.typography.bodyLarge.copy(
                        fontSize = (16 * userPreferences.fontSize.scale).sp,
                        lineHeight = (24 * userPreferences.fontSize.scale).sp,
                        color = MaterialTheme.colorScheme.onSurface
                    ),
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = Color.Transparent,
                        unfocusedContainerColor = Color.Transparent,
                        disabledContainerColor = Color.Transparent,
                        focusedIndicatorColor = Color.Transparent,
                        unfocusedIndicatorColor = Color.Transparent
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("note_content_input")
                )
            }

            // Section: Checklists / To-Dos
            item {
                Spacer(modifier = Modifier.height(16.dp))
                HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = "قائمة المهام / Checklist",
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.height(8.dp))
            }

            // Checklist Items
            itemsIndexed(checklistItems, key = { _, item -> item.id }) { index, item ->
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                ) {
                    Checkbox(
                        checked = item.isDone,
                        onCheckedChange = { isChecked ->
                            val updated = checklistItems.toMutableList()
                            updated[index] = item.copy(isDone = isChecked)
                            checklistItems = updated
                            triggerAutoSave()
                        },
                        modifier = Modifier.testTag("checklist_checkbox_$index")
                    )
                    Text(
                        text = item.text,
                        style = MaterialTheme.typography.bodyMedium.copy(
                            fontSize = (15 * userPreferences.fontSize.scale).sp,
                            textDecoration = if (item.isDone) TextDecoration.LineThrough else null
                        ),
                        color = if (item.isDone) MaterialTheme.colorScheme.outline else MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier
                            .weight(1f)
                            .padding(start = 4.dp)
                    )
                    IconButton(
                        onClick = {
                            val updated = checklistItems.toMutableList()
                            updated.removeAt(index)
                            checklistItems = updated
                            triggerAutoSave()
                        },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Remove Item",
                            tint = MaterialTheme.colorScheme.outline,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }

            // Add Checklist Item Field
            item {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp)
                ) {
                    OutlinedTextField(
                        value = newChecklistInput,
                        onValueChange = { newChecklistInput = it },
                        placeholder = { Text("إضافة عنصر جديد… / Add list item…") },
                        singleLine = true,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("add_checklist_input")
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    IconButton(
                        onClick = {
                            if (newChecklistInput.isNotBlank()) {
                                val newItem = ChecklistItem(
                                    id = java.util.UUID.randomUUID().toString(),
                                    text = newChecklistInput.trim(),
                                    isDone = false
                                )
                                checklistItems = checklistItems + newItem
                                newChecklistInput = ""
                                triggerAutoSave()
                            }
                        },
                        enabled = newChecklistInput.isNotBlank(),
                        modifier = Modifier.testTag("add_checklist_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.AddCircle,
                            contentDescription = "Add Item",
                            tint = if (newChecklistInput.isNotBlank()) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline
                        )
                    }
                }
            }
        }
    }

    // Color Palette Bottom Sheet
    if (showColorPickerSheet) {
        ModalBottomSheet(
            onDismissRequest = { showColorPickerSheet = false }
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text(
                    text = "اختر لون الملاحظة / Note Background Color",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(16.dp))
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(NoteColorPalette) { colorOption ->
                        val isSelected = selectedColorHex.equals(colorOption.hex, ignoreCase = true)
                        val displayColor = if (colorOption.hex == "#00000000") {
                            MaterialTheme.colorScheme.surfaceVariant
                        } else {
                            if (isDark) colorOption.darkColor else colorOption.lightColor
                        }

                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.clickable {
                                selectedColorHex = colorOption.hex
                                triggerAutoSave()
                                showColorPickerSheet = false
                            }
                        ) {
                            Box(
                                contentAlignment = Alignment.Center,
                                modifier = Modifier
                                    .size(46.dp)
                                    .background(displayColor, CircleShape)
                                    .border(
                                        width = if (isSelected) 2.5.dp else 1.dp,
                                        color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline.copy(alpha = 0.3f),
                                        shape = CircleShape
                                    )
                            ) {
                                if (isSelected) {
                                    Icon(
                                        imageVector = Icons.Default.Check,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = colorOption.name,
                                style = MaterialTheme.typography.labelSmall,
                                fontSize = 10.sp
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }

    // Note Statistics Modal Dialog
    if (showStatsDialog) {
        AlertDialog(
            onDismissRequest = { showStatsDialog = false },
            title = { Text("إحصائيات الملاحظة / Note Metrics") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("عدد الكلمات الإجمالي: $wordCount كلمة")
                    Text("عدد الأحرف والرموز: $charCount حرف")
                    Text("الوقت المقدر للقراءة: حوالي $readingTimeMinutes دقيقة")
                    Text("عناصر المهام: ${checklistItems.count { it.isDone }} مكتملة من إجمالي ${checklistItems.size}")
                }
            },
            confirmButton = {
                Button(onClick = { showStatsDialog = false }) {
                    Text("حسناً / Close")
                }
            }
        )
    }
}
