package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)

// Note Background Color Palette (harmonious in light and dark mode)
data class NoteColorOption(val name: String, val hex: String, val lightColor: Color, val darkColor: Color)

val NoteColorPalette = listOf(
    NoteColorOption("Default", "#00000000", Color.Transparent, Color.Transparent),
    NoteColorOption("Soft Coral", "#FFF1F2", Color(0xFFFFF1F2), Color(0xFF4C1D24)),
    NoteColorOption("Warm Amber", "#FEF3C7", Color(0xFFFEF3C7), Color(0xFF452D12)),
    NoteColorOption("Mint Green", "#D1FAE5", Color(0xFFD1FAE5), Color(0xFF133E2B)),
    NoteColorOption("Sky Blue", "#E0F2FE", Color(0xFFE0F2FE), Color(0xFF153752)),
    NoteColorOption("Lavender", "#EDE9FE", Color(0xFFEDE9FE), Color(0xFF2E2452)),
    NoteColorOption("Soft Rose", "#FCE7F3", Color(0xFFFCE7F3), Color(0xFF471F36)),
    NoteColorOption("Slate Gray", "#F1F5F9", Color(0xFFF1F5F9), Color(0xFF242C38)),
    NoteColorOption("Teal Oasis", "#CCFBF1", Color(0xFFCCFBF1), Color(0xFF133832))
)

fun getNoteCardColor(hex: String, isDark: Boolean, defaultCardColor: Color): Color {
    val option = NoteColorPalette.firstOrNull { it.hex.equals(hex, ignoreCase = true) }
    return if (option == null || option.hex == "#00000000") {
        defaultCardColor
    } else {
        if (isDark) option.darkColor else option.lightColor
    }
}
