package com.example.util

import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Build
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import androidx.core.content.FileProvider
import com.example.model.Category
import com.example.model.ChecklistItem
import com.example.model.Note
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.*

object NotePdfExporter {

    private const val PAGE_WIDTH = 595 // A4 standard points
    private const val PAGE_HEIGHT = 842 // A4 standard points
    private const val MARGIN_HORIZONTAL = 45f
    private const val MARGIN_TOP = 45f
    private const val MARGIN_BOTTOM = 55f
    private const val CONTENT_WIDTH = (PAGE_WIDTH - (MARGIN_HORIZONTAL * 2)).toInt()

    fun exportNoteToPdf(
        context: Context,
        note: Note,
        category: Category?,
        checklistItems: List<ChecklistItem>
    ): File {
        val pdfsDir = File(context.cacheDir, "pdfs").apply { mkdirs() }
        val safeTitle = note.title.trim().replace("[^a-zA-Z0-9_\\u0600-\\u06FF]".toRegex(), "_").take(25)
        val fileName = if (safeTitle.isNotBlank()) "Note_${safeTitle}_${System.currentTimeMillis()}.pdf" else "Note_${note.id}_${System.currentTimeMillis()}.pdf"
        val pdfFile = File(pdfsDir, fileName)

        try {
            exportViaAndroidPdfDocument(pdfFile, note, category, checklistItems)
            return pdfFile
        } catch (_: Throwable) {
            // When running in host JVM / Robolectric environment where native libpdf JNI is not loaded
            generateStandardPdfFallback(pdfFile, note, category, checklistItems)
            return pdfFile
        }
    }

    private fun exportViaAndroidPdfDocument(
        targetFile: File,
        note: Note,
        category: Category?,
        checklistItems: List<ChecklistItem>
    ) {
        val pdfDocument = PdfDocument()
        var pageNumber = 1

        var currentPage = pdfDocument.startPage(
            PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, pageNumber).create()
        )
        var canvas = currentPage.canvas
        var currentY = MARGIN_TOP

        // Paints
        val brandPaint = Paint().apply {
            color = Color.parseColor("#4F46E5")
            style = Paint.Style.FILL
            isAntiAlias = true
        }

        val brandTextPaint = Paint().apply {
            color = Color.WHITE
            textSize = 10f
            isFakeBoldText = true
            isAntiAlias = true
        }

        val titlePaint = TextPaint().apply {
            color = Color.parseColor("#0F172A")
            textSize = 20f
            isFakeBoldText = true
            isAntiAlias = true
        }

        val metaPaint = Paint().apply {
            color = Color.parseColor("#64748B")
            textSize = 10f
            isAntiAlias = true
        }

        val dividerPaint = Paint().apply {
            color = Color.parseColor("#E2E8F0")
            strokeWidth = 1.2f
            style = Paint.Style.STROKE
        }

        val contentTextPaint = TextPaint().apply {
            color = Color.parseColor("#334155")
            textSize = 12f
            isAntiAlias = true
        }

        val checklistTextPaint = TextPaint().apply {
            color = Color.parseColor("#1E293B")
            textSize = 11.5f
            isAntiAlias = true
        }

        val checklistDonePaint = TextPaint().apply {
            color = Color.parseColor("#94A3B8")
            textSize = 11.5f
            isAntiAlias = true
        }

        val checkboxBorderPaint = Paint().apply {
            color = Color.parseColor("#64748B")
            style = Paint.Style.STROKE
            strokeWidth = 1.5f
            isAntiAlias = true
        }

        val checkboxDonePaint = Paint().apply {
            color = Color.parseColor("#10B981")
            style = Paint.Style.FILL
            isAntiAlias = true
        }

        val checkmarkPaint = Paint().apply {
            color = Color.WHITE
            strokeWidth = 1.8f
            style = Paint.Style.STROKE
            isAntiAlias = true
        }

        fun drawHeaderAndTitle() {
            // Header Bar Badge: NOTEFLOW
            val badgeRect = RectF(MARGIN_HORIZONTAL, currentY, MARGIN_HORIZONTAL + 75f, currentY + 18f)
            canvas.drawRoundRect(badgeRect, 4f, 4f, brandPaint)
            canvas.drawText("NOTEFLOW", MARGIN_HORIZONTAL + 8f, currentY + 13f, brandTextPaint)

            // Date on top right
            val dateFormat = SimpleDateFormat("EEEE, d MMMM yyyy", Locale.getDefault())
            val dateStr = dateFormat.format(Date(note.updatedAt))
            val dateWidth = metaPaint.measureText(dateStr)
            canvas.drawText(dateStr, PAGE_WIDTH - MARGIN_HORIZONTAL - dateWidth, currentY + 13f, metaPaint)

            currentY += 32f

            // Note Title
            val titleText = if (note.title.isNotBlank()) note.title else "Untitled Note"
            val titleLayout = createStaticLayout(titleText, titlePaint, CONTENT_WIDTH)
            canvas.save()
            canvas.translate(MARGIN_HORIZONTAL, currentY)
            titleLayout.draw(canvas)
            canvas.restore()
            currentY += titleLayout.height + 12f

            // Category & Status Metadata Row
            var metaText = ""
            if (category != null) {
                metaText += "🏷️ Category: ${category.name}   "
            }
            if (note.isPinned) {
                metaText += "📌 Pinned   "
            }
            if (note.isFavorite) {
                metaText += "⭐ Favorite   "
            }
            if (metaText.isNotBlank()) {
                canvas.drawText(metaText.trim(), MARGIN_HORIZONTAL, currentY, metaPaint)
                currentY += 16f
            }

            // Divider Line
            canvas.drawLine(MARGIN_HORIZONTAL, currentY, PAGE_WIDTH - MARGIN_HORIZONTAL, currentY, dividerPaint)
            currentY += 18f
        }

        fun startNewPage() {
            pdfDocument.finishPage(currentPage)
            pageNumber++
            currentPage = pdfDocument.startPage(
                PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, pageNumber).create()
            )
            canvas = currentPage.canvas
            currentY = MARGIN_TOP

            val continuingText = "Noteflow • ${note.title.take(30)}"
            canvas.drawText(continuingText, MARGIN_HORIZONTAL, currentY, metaPaint)
            currentY += 8f
            canvas.drawLine(MARGIN_HORIZONTAL, currentY, PAGE_WIDTH - MARGIN_HORIZONTAL, currentY, dividerPaint)
            currentY += 20f
        }

        // Draw header
        drawHeaderAndTitle()

        // 1. Draw Content Paragraphs
        if (note.content.isNotBlank()) {
            val paragraphs = note.content.split("\n")
            for (para in paragraphs) {
                val paraText = if (para.isBlank()) " " else para
                val layout = createStaticLayout(paraText, contentTextPaint, CONTENT_WIDTH)

                if (currentY + layout.height > PAGE_HEIGHT - MARGIN_BOTTOM) {
                    startNewPage()
                }

                canvas.save()
                canvas.translate(MARGIN_HORIZONTAL, currentY)
                layout.draw(canvas)
                canvas.restore()

                currentY += layout.height + 6f
            }
            currentY += 12f
        }

        // 2. Draw Checklists
        if (checklistItems.isNotEmpty()) {
            if (currentY + 40f > PAGE_HEIGHT - MARGIN_BOTTOM) {
                startNewPage()
            }

            val sectionPaint = TextPaint().apply {
                color = Color.parseColor("#4F46E5")
                textSize = 13f
                isFakeBoldText = true
                isAntiAlias = true
            }
            canvas.drawText("قائمة المهام / Checklist:", MARGIN_HORIZONTAL, currentY, sectionPaint)
            currentY += 18f

            for (item in checklistItems) {
                val itemText = item.text
                val textPaint = if (item.isDone) checklistDonePaint else checklistTextPaint
                val itemLayout = createStaticLayout(itemText, textPaint, CONTENT_WIDTH - 25)

                val requiredHeight = maxOf(18f, itemLayout.height.toFloat() + 6f)
                if (currentY + requiredHeight > PAGE_HEIGHT - MARGIN_BOTTOM) {
                    startNewPage()
                }

                val checkboxY = currentY + 2f
                val checkboxRect = RectF(MARGIN_HORIZONTAL, checkboxY, MARGIN_HORIZONTAL + 14f, checkboxY + 14f)

                if (item.isDone) {
                    canvas.drawRoundRect(checkboxRect, 3f, 3f, checkboxDonePaint)
                    canvas.drawLine(MARGIN_HORIZONTAL + 3f, checkboxY + 7f, MARGIN_HORIZONTAL + 6f, checkboxY + 11f, checkmarkPaint)
                    canvas.drawLine(MARGIN_HORIZONTAL + 6f, checkboxY + 11f, MARGIN_HORIZONTAL + 11f, checkboxY + 3.5f, checkmarkPaint)
                } else {
                    canvas.drawRoundRect(checkboxRect, 3f, 3f, checkboxBorderPaint)
                }

                canvas.save()
                canvas.translate(MARGIN_HORIZONTAL + 22f, currentY)
                itemLayout.draw(canvas)
                canvas.restore()

                currentY += requiredHeight
            }
        }

        // Footer
        val footerY = PAGE_HEIGHT - 35f
        canvas.drawLine(MARGIN_HORIZONTAL, footerY, PAGE_WIDTH - MARGIN_HORIZONTAL, footerY, dividerPaint)
        val footerText = "Generated with Noteflow • Offline Note Document"
        canvas.drawText(footerText, MARGIN_HORIZONTAL, footerY + 18f, metaPaint)

        pdfDocument.finishPage(currentPage)

        FileOutputStream(targetFile).use { out ->
            pdfDocument.writeTo(out)
        }
        pdfDocument.close()
    }

    private fun generateStandardPdfFallback(
        targetFile: File,
        note: Note,
        category: Category?,
        checklistItems: List<ChecklistItem>
    ) {
        val streamContent = StringBuilder()
        streamContent.append("BT\n")
        streamContent.append("/F1 18 Tf\n")
        streamContent.append("45 780 Td\n")
        val escapedTitle = escapePdfString(if (note.title.isNotBlank()) note.title else "Untitled Note")
        streamContent.append("($escapedTitle) Tj\n")

        streamContent.append("/F1 10 Tf\n")
        streamContent.append("0 -24 Td\n")
        val dateStr = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date(note.updatedAt))
        val catStr = if (category != null) " | Category: ${category.name}" else ""
        streamContent.append("(${escapePdfString("Date: $dateStr$catStr")}) Tj\n")

        streamContent.append("/F1 12 Tf\n")
        streamContent.append("0 -24 Td\n")

        val lines = note.content.lines().take(40)
        for (line in lines) {
            val escapedLine = escapePdfString(line)
            streamContent.append("($escapedLine) Tj\n")
            streamContent.append("0 -16 Td\n")
        }

        if (checklistItems.isNotEmpty()) {
            streamContent.append("/F1 13 Tf\n")
            streamContent.append("0 -10 Td\n")
            streamContent.append("(Checklist:) Tj\n")
            streamContent.append("/F1 11 Tf\n")
            streamContent.append("0 -16 Td\n")
            for (item in checklistItems.take(20)) {
                val mark = if (item.isDone) "[x]" else "[ ]"
                val escaped = escapePdfString("$mark ${item.text}")
                streamContent.append("($escaped) Tj\n")
                streamContent.append("0 -15 Td\n")
            }
        }

        streamContent.append("ET\n")
        val streamBytes = streamContent.toString().toByteArray(Charsets.ISO_8859_1)

        val out = StringBuilder()
        out.append("%PDF-1.4\n")
        val obj1Offset = out.length
        out.append("1 0 obj\n<< /Type /Catalog /Pages 2 0 R >>\nendobj\n")
        val obj2Offset = out.length
        out.append("2 0 obj\n<< /Type /Pages /Kids [3 0 R] /Count 1 >>\nendobj\n")
        val obj3Offset = out.length
        out.append("3 0 obj\n<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 4 0 R >> >> /Contents 5 0 R >>\nendobj\n")
        val obj4Offset = out.length
        out.append("4 0 obj\n<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>\nendobj\n")
        val obj5Offset = out.length
        out.append("5 0 obj\n<< /Length ${streamBytes.size} >>\nstream\n")
        out.append(streamContent.toString())
        out.append("endstream\nendobj\n")

        val xrefOffset = out.length
        out.append("xref\n")
        out.append("0 6\n")
        out.append("0000000000 65535 f \n")
        out.append(String.format(Locale.US, "%010d 00000 n \n", obj1Offset))
        out.append(String.format(Locale.US, "%010d 00000 n \n", obj2Offset))
        out.append(String.format(Locale.US, "%010d 00000 n \n", obj3Offset))
        out.append(String.format(Locale.US, "%010d 00000 n \n", obj4Offset))
        out.append(String.format(Locale.US, "%010d 00000 n \n", obj5Offset))
        out.append("trailer\n<< /Size 6 /Root 1 0 R >>\n")
        out.append("startxref\n$xrefOffset\n%%EOF\n")

        targetFile.writeText(out.toString(), Charsets.ISO_8859_1)
    }

    private fun escapePdfString(text: String): String {
        return text.replace("\\", "\\\\")
            .replace("(", "\\(")
            .replace(")", "\\)")
            .filter { it.code in 32..126 } // Standard ASCII for Type1 font in fallback
    }

    private fun createStaticLayout(text: String, textPaint: TextPaint, width: Int): StaticLayout {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            StaticLayout.Builder.obtain(text, 0, text.length, textPaint, width)
                .setAlignment(Layout.Alignment.ALIGN_NORMAL)
                .setLineSpacing(1.2f, 1.2f)
                .setIncludePad(true)
                .build()
        } else {
            @Suppress("DEPRECATION")
            StaticLayout(
                text,
                textPaint,
                width,
                Layout.Alignment.ALIGN_NORMAL,
                1.2f,
                1.2f,
                true
            )
        }
    }

    fun shareOrOpenPdf(context: Context, file: File, noteTitle: String) {
        val uri: Uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )

        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, if (noteTitle.isNotBlank()) noteTitle else "Noteflow Note")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }

        val chooser = Intent.createChooser(intent, "Share Note as PDF")
        chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(chooser)
    }
}
