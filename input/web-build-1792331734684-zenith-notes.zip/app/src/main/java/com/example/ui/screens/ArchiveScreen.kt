package com.example.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Archive
import androidx.compose.material.icons.outlined.Unarchive
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.model.UserPreferences
import com.example.ui.components.NoteCard
import com.example.viewmodel.NotesViewModel

@Composable
fun ArchiveScreen(
    viewModel: NotesViewModel,
    userPreferences: UserPreferences,
    onNoteClick: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    val archivedNotes by viewModel.archivedNotes.collectAsState()
    val categories by viewModel.categories.collectAsState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        Spacer(modifier = Modifier.height(12.dp))
        Text(
            text = "الأرشيف / Archive",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
        )
        Spacer(modifier = Modifier.height(12.dp))

        if (archivedNotes.isEmpty()) {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .fillMaxSize()
                    .padding(bottom = 72.dp)
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(24.dp)
                ) {
                    Icon(
                        imageVector = Icons.Outlined.Archive,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.outline,
                        modifier = Modifier.size(64.dp)
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "الأرشيف فارغ\nArchive is empty",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "الملاحظات المؤرشفة تظهر هنا بعيداً عن القائمة الرئيسية\nArchived notes will appear here",
                        style = MaterialTheme.typography.bodyMedium,
                        textAlign = TextAlign.Center,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(bottom = 88.dp, top = 4.dp),
                modifier = Modifier
                    .fillMaxSize()
                    .testTag("archive_list")
            ) {
                items(archivedNotes, key = { it.id }) { note ->
                    val cat = categories.firstOrNull { it.id == note.categoryId }
                    val checklist = remember(note.checklistJson) {
                        viewModel.parseChecklist(note.checklistJson)
                    }
                    Column {
                        NoteCard(
                            note = note,
                            category = cat,
                            userPreferences = userPreferences,
                            parsedChecklist = checklist,
                            onClick = { onNoteClick(note.id) },
                            onPinClick = { viewModel.togglePin(note) },
                            onFavoriteClick = { viewModel.toggleFavorite(note) },
                            onDeleteClick = { viewModel.deleteNote(note) }
                        )
                        Row(
                            horizontalArrangement = Arrangement.End,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 4.dp, end = 8.dp)
                        ) {
                            TextButton(
                                onClick = { viewModel.toggleArchive(note) },
                                modifier = Modifier.testTag("unarchive_button_${note.id}")
                            ) {
                                Icon(
                                    imageVector = Icons.Outlined.Unarchive,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("إلغاء الأرشفة / Unarchive")
                            }
                        }
                    }
                }
            }
        }
    }
}
