package com.example.data.repository

import com.example.data.local.CategoryDao
import com.example.data.local.NoteDao
import com.example.model.BackupData
import com.example.model.Category
import com.example.model.ChecklistItem
import com.example.model.Note
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

class NoteRepository(
    private val noteDao: NoteDao,
    private val categoryDao: CategoryDao
) {
    private val moshi: Moshi = Moshi.Builder()
        .addLast(KotlinJsonAdapterFactory())
        .build()

    private val checklistAdapter by lazy {
        val type = Types.newParameterizedType(List::class.java, ChecklistItem::class.java)
        moshi.adapter<List<ChecklistItem>>(type)
    }

    private val backupAdapter by lazy {
        moshi.adapter(BackupData::class.java)
    }

    val activeNotes: Flow<List<Note>> = noteDao.getActiveNotes()
    val favoriteNotes: Flow<List<Note>> = noteDao.getFavoriteNotes()
    val archivedNotes: Flow<List<Note>> = noteDao.getArchivedNotes()
    val trashNotes: Flow<List<Note>> = noteDao.getTrashNotes()
    val allCategories: Flow<List<Category>> = categoryDao.getAllCategories()

    fun searchNotes(query: String): Flow<List<Note>> {
        return noteDao.searchNotes(query.trim())
    }

    fun getNoteByIdFlow(id: Long): Flow<Note?> = noteDao.getNoteByIdFlow(id)

    suspend fun getNoteById(id: Long): Note? = withContext(Dispatchers.IO) {
        noteDao.getNoteById(id)
    }

    suspend fun saveNote(note: Note): Long = withContext(Dispatchers.IO) {
        val updatedNote = note.copy(updatedAt = System.currentTimeMillis())
        noteDao.insertOrUpdate(updatedNote)
    }

    suspend fun moveToTrash(id: Long) = withContext(Dispatchers.IO) {
        noteDao.setDeleted(id, true)
    }

    suspend fun restoreFromTrash(id: Long) = withContext(Dispatchers.IO) {
        noteDao.setDeleted(id, false)
    }

    suspend fun deletePermanently(id: Long) = withContext(Dispatchers.IO) {
        noteDao.deletePermanently(id)
    }

    suspend fun emptyTrash() = withContext(Dispatchers.IO) {
        noteDao.emptyTrash()
    }

    suspend fun togglePin(id: Long, currentPinned: Boolean) = withContext(Dispatchers.IO) {
        noteDao.setPinned(id, !currentPinned)
    }

    suspend fun toggleFavorite(id: Long, currentFavorite: Boolean) = withContext(Dispatchers.IO) {
        noteDao.setFavorite(id, !currentFavorite)
    }

    suspend fun toggleArchive(id: Long, currentArchived: Boolean) = withContext(Dispatchers.IO) {
        noteDao.setArchived(id, !currentArchived)
    }

    suspend fun saveCategory(category: Category): Long = withContext(Dispatchers.IO) {
        categoryDao.insertOrUpdate(category)
    }

    suspend fun deleteCategory(id: Long) = withContext(Dispatchers.IO) {
        categoryDao.deleteCategory(id)
    }

    fun parseChecklist(json: String?): List<ChecklistItem> {
        if (json.isNullOrBlank() || json == "[]") return emptyList()
        return try {
            checklistAdapter.fromJson(json) ?: emptyList()
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun serializeChecklist(items: List<ChecklistItem>): String {
        return try {
            checklistAdapter.toJson(items)
        } catch (_: Exception) {
            "[]"
        }
    }

    suspend fun createBackupJson(): String = withContext(Dispatchers.IO) {
        val notes = noteDao.getAllNotesRaw()
        val categories = categoryDao.getAllCategoriesRaw()
        val backupData = BackupData(
            version = 1,
            exportDate = System.currentTimeMillis(),
            app = "Noteflow",
            notes = notes,
            categories = categories
        )
        backupAdapter.toJson(backupData)
    }

    suspend fun restoreBackupJson(jsonString: String): Result<Int> = withContext(Dispatchers.IO) {
        try {
            val backup = backupAdapter.fromJson(jsonString)
                ?: return@withContext Result.failure(IllegalArgumentException("Invalid JSON format"))

            if (backup.version <= 0 || (backup.notes.isEmpty() && backup.categories.isEmpty())) {
                return@withContext Result.failure(IllegalArgumentException("Backup file contains no data or unsupported version"))
            }

            if (backup.categories.isNotEmpty()) {
                categoryDao.insertAll(backup.categories)
            }
            if (backup.notes.isNotEmpty()) {
                noteDao.insertAll(backup.notes)
            }

            Result.success(backup.notes.size)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun formatNoteAsText(note: Note): String {
        val builder = java.lang.StringBuilder()
        if (note.title.isNotBlank()) {
            builder.append(note.title).append("\n\n")
        }
        if (note.content.isNotBlank()) {
            builder.append(note.content).append("\n\n")
        }
        val checklist = parseChecklist(note.checklistJson)
        if (checklist.isNotEmpty()) {
            builder.append("Checklist:\n")
            checklist.forEach { item ->
                val checkMark = if (item.isDone) "[x]" else "[ ]"
                builder.append("$checkMark ${item.text}\n")
            }
        }
        return builder.toString().trim()
    }
}
