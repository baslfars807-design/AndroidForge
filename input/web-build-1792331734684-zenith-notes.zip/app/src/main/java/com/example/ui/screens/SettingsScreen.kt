package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.*
import com.example.ui.components.NoteCard
import com.example.viewmodel.NotesViewModel
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen(
    viewModel: NotesViewModel,
    userPreferences: UserPreferences,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    var showImportDialog by remember { mutableStateOf(false) }
    var showExportSuccessDialog by remember { mutableStateOf<String?>(null) }
    var importJsonText by remember { mutableStateOf("") }
    var importStatusMessage by remember { mutableStateOf<String?>(null) }

    // Sample note for Live Preview
    val sampleNote = remember {
        Note(
            id = 999,
            title = "معاينة المظهر / Theme Live Preview",
            content = "هكذا ستبدو ملاحظاتك مع خيارات المظهر والخط والكثافة المحددة.\nThis is a real-time preview of your selected settings.",
            colorHex = "#EDE9FE",
            isPinned = true,
            isFavorite = true
        )
    }

    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 96.dp),
        modifier = modifier
            .fillMaxSize()
            .testTag("settings_screen")
    ) {
        item {
            Text(
                text = "الإعدادات وتخصيص المظهر / Settings & Theme",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
        }

        // --- Live Preview Section ---
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "معاينة مباشرة / Live Preview",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    NoteCard(
                        note = sampleNote,
                        category = Category(name = "أفكار / Ideas"),
                        userPreferences = userPreferences,
                        parsedChecklist = listOf(
                            ChecklistItem("1", "إنجاز المهام / Finish task", true),
                            ChecklistItem("2", "حفظ الإعدادات / Save preferences", false)
                        ),
                        onClick = {},
                        onPinClick = {},
                        onFavoriteClick = {},
                        onDeleteClick = {}
                    )
                }
            }
        }

        // --- Theme Mode (Light / Dark / System) ---
        item {
            SettingsCard(title = "وضع المظهر / Theme Mode") {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    ThemeMode.values().forEach { mode ->
                        val isSelected = userPreferences.themeMode == mode
                        val label = when (mode) {
                            ThemeMode.SYSTEM -> "تلقائي / System"
                            ThemeMode.LIGHT -> "فاتح / Light"
                            ThemeMode.DARK -> "داكن / Dark"
                        }
                        FilterChip(
                            selected = isSelected,
                            onClick = { viewModel.setThemeMode(mode) },
                            label = { Text(label, fontSize = 12.sp) },
                            leadingIcon = if (isSelected) {
                                { Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp)) }
                            } else null,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }

        // --- Primary Color Selection ---
        item {
            SettingsCard(title = "اللون الأساسي للتطبيق / Primary Color Accent") {
                Row(
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    PrimaryColorTheme.values().forEach { colorTheme ->
                        val isSelected = userPreferences.primaryColor == colorTheme
                        val color = Color(colorTheme.colorHex)
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier
                                .size(42.dp)
                                .background(color, CircleShape)
                                .clickable { viewModel.setPrimaryColor(colorTheme) }
                        ) {
                            if (isSelected) {
                                Icon(
                                    imageVector = Icons.Default.Check,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        // --- View Mode (Grid vs List) ---
        item {
            SettingsCard(title = "طريقة عرض الملاحظات / View Layout") {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    FilterChip(
                        selected = userPreferences.viewMode == ViewMode.GRID,
                        onClick = { viewModel.setViewMode(ViewMode.GRID) },
                        label = { Text("شبكة / Grid (2 cols)") },
                        leadingIcon = { Icon(Icons.Outlined.GridView, contentDescription = null, modifier = Modifier.size(18.dp)) },
                        modifier = Modifier.weight(1f)
                    )
                    FilterChip(
                        selected = userPreferences.viewMode == ViewMode.LIST,
                        onClick = { viewModel.setViewMode(ViewMode.LIST) },
                        label = { Text("قائمة / List (1 col)") },
                        leadingIcon = { Icon(Icons.Outlined.ViewAgenda, contentDescription = null, modifier = Modifier.size(18.dp)) },
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // --- Font Size Selection ---
        item {
            SettingsCard(title = "حجم خط المحتوى / Content Font Size") {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    FontSizePreference.values().forEach { sizePref ->
                        val isSelected = userPreferences.fontSize == sizePref
                        val label = when (sizePref) {
                            FontSizePreference.SMALL -> "صغير / Small (85%)"
                            FontSizePreference.MEDIUM -> "متوسط / Normal"
                            FontSizePreference.LARGE -> "كبير / Large (120%)"
                        }
                        FilterChip(
                            selected = isSelected,
                            onClick = { viewModel.setFontSize(sizePref) },
                            label = { Text(label, fontSize = 11.sp) },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }

        // --- Card Density ---
        item {
            SettingsCard(title = "كثافة عرض البطاقات / Card Density") {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    CardDensityPreference.values().forEach { densityPref ->
                        val isSelected = userPreferences.cardDensity == densityPref
                        val label = when (densityPref) {
                            CardDensityPreference.COMFORTABLE -> "مريح / Comfortable"
                            CardDensityPreference.COMPACT -> "مضغوط / Compact"
                        }
                        FilterChip(
                            selected = isSelected,
                            onClick = { viewModel.setCardDensity(densityPref) },
                            label = { Text(label, fontSize = 12.sp) },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }

        // --- Backup & Restore Section ---
        item {
            SettingsCard(title = "النسخ الاحتياطي والاستعادة / Backup & Restore") {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "حفظ واستعادة كامل الملاحظات والتصنيفات والألوان كملف JSON محلي موثوق.\nSave and restore all notes, checklists, and categories locally.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Button(
                            onClick = {
                                coroutineScope.launch {
                                    val json = viewModel.exportBackupJson()
                                    showExportSuccessDialog = json
                                }
                            },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("export_backup_button")
                        ) {
                            Icon(Icons.Outlined.FileDownload, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("تصدير النسخة / Export")
                        }

                        OutlinedButton(
                            onClick = {
                                importJsonText = ""
                                importStatusMessage = null
                                showImportDialog = true
                            },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("import_backup_button")
                        ) {
                            Icon(Icons.Outlined.FileUpload, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("استيراد / Import")
                        }
                    }
                }
            }
        }
    }

    // Export Success Dialog
    showExportSuccessDialog?.let { json ->
        AlertDialog(
            onDismissRequest = { showExportSuccessDialog = null },
            title = { Text("تم إنشاء النسخة الاحتياطية / Backup Ready") },
            text = {
                Column {
                    Text("تم إنشاء كود النسخة الاحتياطية بنجاح بنسق JSON. يمكنك نسخه أو مشاركته لحفظه بأمان:")
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = json,
                        onValueChange = {},
                        readOnly = true,
                        maxLines = 6,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        clipboard.setPrimaryClip(ClipData.newPlainText("Noteflow Backup", json))
                        showExportSuccessDialog = null
                    }
                ) {
                    Text("نسخ JSON / Copy")
                }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        val sendIntent = Intent().apply {
                            action = Intent.ACTION_SEND
                            putExtra(Intent.EXTRA_TEXT, json)
                            type = "application/json"
                        }
                        context.startActivity(Intent.createChooser(sendIntent, "Share Noteflow Backup"))
                        showExportSuccessDialog = null
                    }
                ) {
                    Text("مشاركة / Share")
                }
            }
        )
    }

    // Import Dialog
    if (showImportDialog) {
        AlertDialog(
            onDismissRequest = { showImportDialog = false },
            title = { Text("استيراد نسخة احتياطية / Import Backup") },
            text = {
                Column {
                    Text("الصق بيانات النسخة الاحتياطية (تنسيق JSON) للتحقق منها واستعادتها:")
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = importJsonText,
                        onValueChange = {
                            importJsonText = it
                            importStatusMessage = null
                        },
                        placeholder = { Text("{\"version\":1, \"app\":\"Noteflow\", ...}") },
                        maxLines = 6,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("import_json_field")
                    )
                    importStatusMessage?.let { status ->
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = status,
                            color = MaterialTheme.colorScheme.error,
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        coroutineScope.launch {
                            val res = viewModel.importBackupJson(importJsonText)
                            res.onSuccess {
                                showImportDialog = false
                            }.onFailure { err ->
                                importStatusMessage = "خطأ في الاستيراد: ${err.message}"
                            }
                        }
                    },
                    enabled = importJsonText.isNotBlank(),
                    modifier = Modifier.testTag("confirm_import_button")
                ) {
                    Text("استعادة / Restore")
                }
            },
            dismissButton = {
                TextButton(onClick = { showImportDialog = false }) {
                    Text("إلغاء / Cancel")
                }
            }
        )
    }
}

@Composable
fun SettingsCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)
        ),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(modifier = Modifier.height(10.dp))
            content()
        }
    }
}
