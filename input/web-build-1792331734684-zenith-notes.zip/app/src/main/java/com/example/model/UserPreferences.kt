package com.example.model

enum class ThemeMode {
    SYSTEM, LIGHT, DARK
}

enum class PrimaryColorTheme(val title: String, val colorHex: Long) {
    INDIGO("Indigo", 0xFF6366F1),
    TEAL("Teal", 0xFF0D9488),
    ROSE("Rose", 0xFFE11D48),
    AMBER("Amber", 0xFFD97706),
    EMERALD("Emerald", 0xFF059669),
    PURPLE("Purple", 0xFF9333EA)
}

enum class ViewMode {
    GRID, LIST
}

enum class FontSizePreference(val title: String, val scale: Float) {
    SMALL("Small", 0.85f),
    MEDIUM("Medium", 1.0f),
    LARGE("Large", 1.2f)
}

enum class CardDensityPreference(val title: String) {
    COMFORTABLE("Comfortable"),
    COMPACT("Compact")
}

data class UserPreferences(
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val primaryColor: PrimaryColorTheme = PrimaryColorTheme.INDIGO,
    val viewMode: ViewMode = ViewMode.GRID,
    val fontSize: FontSizePreference = FontSizePreference.MEDIUM,
    val cardDensity: CardDensityPreference = CardDensityPreference.COMFORTABLE
)
