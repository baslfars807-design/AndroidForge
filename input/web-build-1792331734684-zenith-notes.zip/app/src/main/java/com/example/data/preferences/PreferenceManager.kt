package com.example.data.preferences

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import com.example.model.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import java.io.IOException

val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "noteflow_settings")

class PreferenceManager(private val context: Context) {

    private object PreferencesKeys {
        val THEME_MODE = stringPreferencesKey("theme_mode")
        val PRIMARY_COLOR = stringPreferencesKey("primary_color")
        val VIEW_MODE = stringPreferencesKey("view_mode")
        val FONT_SIZE = stringPreferencesKey("font_size")
        val CARD_DENSITY = stringPreferencesKey("card_density")
    }

    val userPreferencesFlow: Flow<UserPreferences> = context.dataStore.data
        .catch { exception ->
            if (exception is IOException) {
                emit(emptyPreferences())
            } else {
                throw exception
            }
        }
        .map { preferences ->
            val themeModeName = preferences[PreferencesKeys.THEME_MODE] ?: ThemeMode.SYSTEM.name
            val primaryColorName = preferences[PreferencesKeys.PRIMARY_COLOR] ?: PrimaryColorTheme.INDIGO.name
            val viewModeName = preferences[PreferencesKeys.VIEW_MODE] ?: ViewMode.GRID.name
            val fontSizeName = preferences[PreferencesKeys.FONT_SIZE] ?: FontSizePreference.MEDIUM.name
            val cardDensityName = preferences[PreferencesKeys.CARD_DENSITY] ?: CardDensityPreference.COMFORTABLE.name

            UserPreferences(
                themeMode = runCatching { ThemeMode.valueOf(themeModeName) }.getOrDefault(ThemeMode.SYSTEM),
                primaryColor = runCatching { PrimaryColorTheme.valueOf(primaryColorName) }.getOrDefault(PrimaryColorTheme.INDIGO),
                viewMode = runCatching { ViewMode.valueOf(viewModeName) }.getOrDefault(ViewMode.GRID),
                fontSize = runCatching { FontSizePreference.valueOf(fontSizeName) }.getOrDefault(FontSizePreference.MEDIUM),
                cardDensity = runCatching { CardDensityPreference.valueOf(cardDensityName) }.getOrDefault(CardDensityPreference.COMFORTABLE)
            )
        }

    suspend fun setThemeMode(themeMode: ThemeMode) {
        context.dataStore.edit { preferences ->
            preferences[PreferencesKeys.THEME_MODE] = themeMode.name
        }
    }

    suspend fun setPrimaryColor(primaryColor: PrimaryColorTheme) {
        context.dataStore.edit { preferences ->
            preferences[PreferencesKeys.PRIMARY_COLOR] = primaryColor.name
        }
    }

    suspend fun setViewMode(viewMode: ViewMode) {
        context.dataStore.edit { preferences ->
            preferences[PreferencesKeys.VIEW_MODE] = viewMode.name
        }
    }

    suspend fun setFontSize(fontSize: FontSizePreference) {
        context.dataStore.edit { preferences ->
            preferences[PreferencesKeys.FONT_SIZE] = fontSize.name
        }
    }

    suspend fun setCardDensity(cardDensity: CardDensityPreference) {
        context.dataStore.edit { preferences ->
            preferences[PreferencesKeys.CARD_DENSITY] = cardDensity.name
        }
    }
}
