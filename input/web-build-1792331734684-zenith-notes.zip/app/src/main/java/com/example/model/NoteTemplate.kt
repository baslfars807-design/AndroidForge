package com.example.model

data class NoteTemplate(
    val id: String,
    val title: String,
    val titleAr: String,
    val description: String,
    val descriptionAr: String,
    val iconEmoji: String,
    val defaultTitle: String,
    val defaultContent: String,
    val checklist: List<String>,
    val defaultColorHex: String = "#00000000"
)

object NoteTemplates {
    val list = listOf(
        NoteTemplate(
            id = "meeting",
            title = "Meeting Minutes",
            titleAr = "محضر اجتماع عمل",
            description = "Agenda, attendees, key discussions & action items",
            descriptionAr = "جدول الأعمال، الحاضرون، النقاط الرئيسية وقائمة المهام",
            iconEmoji = "💼",
            defaultTitle = "محضر اجتماع: ",
            defaultContent = "📅 التاريخ والوقت:\n👥 الحاضرون:\n\n📋 جدول الأعمال والمناقشات:\n- \n- \n\n🎯 القرارات المتخذة:\n- ",
            checklist = listOf("إرسال المحضر لجميع المشاركين", "متابعة المهام الموكلة للأعضاء", "تحديد موعد الاجتماع القادم"),
            defaultColorHex = "#E0F2FE"
        ),
        NoteTemplate(
            id = "daily_journal",
            title = "Daily Journal & Reflection",
            titleAr = "يوميات وتأملات الصباح",
            description = "Gratitude, daily priorities, and thoughts",
            descriptionAr = "الامتنان، أولويات اليوم، والملاحظات الشخصية",
            iconEmoji = "☀️",
            defaultTitle = "يوميات: ",
            defaultContent = "🌟 3 أشياء أنا ممتن لها اليوم:\n1. \n2. \n3. \n\n🎯 الهدف الأهم لإنجازه اليوم:\n- \n\n💭 خواطر وتأملات المساء:\n- ",
            checklist = listOf("شرب 2 لتر ماء", "تمرين رياضي 30 دقيقة", "قراءة 15 صفحة من كتاب"),
            defaultColorHex = "#FEF3C7"
        ),
        NoteTemplate(
            id = "project_plan",
            title = "Project Roadmap",
            titleAr = "خطة مشروع متكاملة",
            description = "Goals, phases, milestones & deliverable checklists",
            descriptionAr = "الأهداف، المراحل، ومراحل التسليم والمهام",
            iconEmoji = "🚀",
            defaultTitle = "خطة مشروع: ",
            defaultContent = "🎯 الهدف من المشروع:\n\n📌 نطاق العمل (Scope):\n- \n- \n\n⚠️ التحديات والمخاطر المتوقعة:\n- ",
            checklist = listOf("تحديد المتطلبات الأساسية", "بناء النموذج الأولي (Prototype)", "مراجعة الجودة والاختبارات", "إطلاق الإصدار النهائي"),
            defaultColorHex = "#EDE9FE"
        ),
        NoteTemplate(
            id = "grocery",
            title = "Smart Shopping List",
            titleAr = "قائمة مشتريات وتسوق",
            description = "Organized checklist for weekly essentials",
            descriptionAr = "قائمة مهام منظمة للطلبات الأسبوعية والمنزلية",
            iconEmoji = "🛒",
            defaultTitle = "قائمة المشتريات",
            defaultContent = "🛒 مشتريات السوبرماركت والمؤونة الأسبوعية:",
            checklist = listOf("خضار وفواكه طازجة", "حليب وبيض وأجبان", "خبز وحبوب", "مستلزمات نظافة وعناية"),
            defaultColorHex = "#D1FAE5"
        ),
        NoteTemplate(
            id = "book_summary",
            title = "Book & Article Summary",
            titleAr = "ملخص كتاب أو مقال",
            description = "Key insights, memorable quotes & reflections",
            descriptionAr = "أهم الأفكار المستفادة، اقتباسات مميزة، وتطبيقات عملية",
            iconEmoji = "📚",
            defaultTitle = "ملخص كتاب: ",
            defaultContent = "📖 اسم الكتاب والمؤلف:\n\n💡 الفكرة المركزية للكتاب:\n\n✨ اقتباسات لا تُنسى:\n- \n\n🚀 كيف سأطبق ما تعلمته في حياتي؟\n- ",
            checklist = listOf("إنهاء قراءة الفصل الأول", "تلخيص النقاط الجوهرية", "مشاركة الأفكار مع صديق"),
            defaultColorHex = "#FCE7F3"
        ),
        NoteTemplate(
            id = "travel",
            title = "Travel & Packing Plan",
            titleAr = "جدول رحلة وتجهيز الحقيبة",
            description = "Flight details, travel itinerary & packing checklist",
            descriptionAr = "بيانات السفر، جدول الأيام، وحقيبة السفر",
            iconEmoji = "✈️",
            defaultTitle = "رحلة إلى: ",
            defaultContent = "🏨 الفندق والإقامة:\n✈️ رحلة الذهاب والعودة:\n\n🗺️ الأماكن السياحية المقترحة:\n- اليوم 1:\n- اليوم 2:\n- اليوم 3:",
            checklist = listOf("جواز السفر والتذاكر", "الشواحن ومحول الكهرباء", "الملابس المناسبة للطقس", "الأدوية والمستلزمات الشخصية"),
            defaultColorHex = "#FFF1F2"
        ),
        NoteTemplate(
            id = "brainstorming",
            title = "Brainstorming & Ideas",
            titleAr = "عصف ذهني وتوليد أفكار",
            description = "Problem solving, pros/cons, and creative ideas",
            descriptionAr = "تحليل المشكلات، المزايا والعيوب، وأفكار إبداعية",
            iconEmoji = "💡",
            defaultTitle = "عصف ذهني: ",
            defaultContent = "❓ المشكلة أو التحدي:\n\n💡 الأفكار المقترحة:\n1. \n2. \n3. \n\n⚖️ المزايا والعيوب لكل حل:\n- فكرة 1:\n- فكرة 2:\n\n🎯 الخطوة التالية للتنفيذ:\n- ",
            checklist = listOf("تصفية أفضل فكرتين", "اختبار الفكرة مع فريق العمل", "بدء خطة التنفيذ"),
            defaultColorHex = "#CCFBF1"
        )
    )
}
