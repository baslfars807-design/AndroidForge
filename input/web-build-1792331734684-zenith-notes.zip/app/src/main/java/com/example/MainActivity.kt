package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.*
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.ui.screens.*
import com.example.ui.theme.NoteflowTheme
import com.example.viewmodel.NotesViewModel
import com.example.viewmodel.ScreenDestination
import kotlinx.coroutines.flow.collectLatest

class MainActivity : ComponentActivity() {
    private val viewModel: NotesViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val userPreferences by viewModel.userPreferences.collectAsState()
            val currentScreen by viewModel.currentScreen.collectAsState()
            val snackbarHostState = remember { SnackbarHostState() }

            // Observe snackbar messages
            LaunchedEffect(Unit) {
                viewModel.snackbarMessage.collectLatest { message ->
                    if (message.contains("moved to Trash", ignoreCase = true)) {
                        val result = snackbarHostState.showSnackbar(
                            message = message,
                            actionLabel = "تراجع / Undo",
                            duration = SnackbarDuration.Short
                        )
                        if (result == SnackbarResult.ActionPerformed) {
                            viewModel.undoDelete()
                        }
                    } else {
                        snackbarHostState.showSnackbar(
                            message = message,
                            duration = SnackbarDuration.Short
                        )
                    }
                }
            }

            NoteflowTheme(
                themeMode = userPreferences.themeMode,
                primaryColorTheme = userPreferences.primaryColor
            ) {
                if (currentScreen is ScreenDestination.Editor) {
                    val noteId = (currentScreen as ScreenDestination.Editor).noteId
                    EditorScreen(
                        noteId = noteId,
                        viewModel = viewModel,
                        userPreferences = userPreferences,
                        onBack = { viewModel.navigateTo(ScreenDestination.Home) }
                    )
                } else {
                    Scaffold(
                        snackbarHost = { SnackbarHost(snackbarHostState) },
                        topBar = {
                            NoteflowTopAppBar(
                                currentScreen = currentScreen,
                                onNavigate = { viewModel.navigateTo(it) }
                            )
                        },
                        bottomBar = {
                            NoteflowBottomNavBar(
                                currentScreen = currentScreen,
                                onNavigate = { viewModel.navigateTo(it) }
                            )
                        },
                        floatingActionButton = {
                            if (currentScreen is ScreenDestination.Home || currentScreen is ScreenDestination.Favorites) {
                                FloatingActionButton(
                                    onClick = { viewModel.openNoteEditor(null) },
                                    containerColor = MaterialTheme.colorScheme.primary,
                                    contentColor = MaterialTheme.colorScheme.onPrimary,
                                    modifier = Modifier.testTag("create_note_fab")
                                ) {
                                    Icon(Icons.Default.Add, contentDescription = "New Note")
                                }
                            }
                        },
                        modifier = Modifier.fillMaxSize()
                    ) { innerPadding ->
                        // Handle back button on sub-screens
                        if (currentScreen !is ScreenDestination.Home) {
                            BackHandler {
                                viewModel.navigateTo(ScreenDestination.Home)
                            }
                        }

                        Box(modifier = Modifier.padding(innerPadding)) {
                            AnimatedContent(
                                targetState = currentScreen,
                                transitionSpec = {
                                    fadeIn() togetherWith fadeOut()
                                },
                                label = "ScreenTransition"
                            ) { screen ->
                                when (screen) {
                                    is ScreenDestination.Home -> HomeScreen(
                                        viewModel = viewModel,
                                        userPreferences = userPreferences,
                                        onNoteClick = { id -> viewModel.openNoteEditor(id) }
                                    )
                                    is ScreenDestination.Favorites -> FavoritesScreen(
                                        viewModel = viewModel,
                                        userPreferences = userPreferences,
                                        onNoteClick = { id -> viewModel.openNoteEditor(id) }
                                    )
                                    is ScreenDestination.Archive -> ArchiveScreen(
                                        viewModel = viewModel,
                                        userPreferences = userPreferences,
                                        onNoteClick = { id -> viewModel.openNoteEditor(id) }
                                    )
                                    is ScreenDestination.Trash -> TrashScreen(
                                        viewModel = viewModel,
                                        userPreferences = userPreferences
                                    )
                                    is ScreenDestination.Categories -> CategoriesScreen(
                                        viewModel = viewModel
                                    )
                                    is ScreenDestination.Templates -> TemplatesScreen(
                                        viewModel = viewModel,
                                        userPreferences = userPreferences,
                                        onTemplateSelect = { template ->
                                            viewModel.createNoteFromTemplate(template)
                                        }
                                    )
                                    is ScreenDestination.Settings -> SettingsScreen(
                                        viewModel = viewModel,
                                        userPreferences = userPreferences
                                    )
                                    is ScreenDestination.Editor -> {
                                        // Handled in root
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NoteflowTopAppBar(
    currentScreen: ScreenDestination,
    onNavigate: (ScreenDestination) -> Unit
) {
    TopAppBar(
        title = {
            Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Outlined.EditNote,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(28.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Noteflow",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
        },
        actions = {
            // Quick access to Archive
            IconButton(
                onClick = { onNavigate(ScreenDestination.Archive) },
                modifier = Modifier.testTag("top_bar_archive_button")
            ) {
                Icon(
                    imageVector = if (currentScreen is ScreenDestination.Archive) Icons.Filled.Archive else Icons.Outlined.Archive,
                    contentDescription = "Archive",
                    tint = if (currentScreen is ScreenDestination.Archive) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            // Quick access to Trash
            IconButton(
                onClick = { onNavigate(ScreenDestination.Trash) },
                modifier = Modifier.testTag("top_bar_trash_button")
            ) {
                Icon(
                    imageVector = if (currentScreen is ScreenDestination.Trash) Icons.Filled.Delete else Icons.Outlined.Delete,
                    contentDescription = "Trash",
                    tint = if (currentScreen is ScreenDestination.Trash) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        },
        colors = TopAppBarDefaults.topAppBarColors(
            containerColor = MaterialTheme.colorScheme.background
        )
    )
}

@Composable
fun NoteflowBottomNavBar(
    currentScreen: ScreenDestination,
    onNavigate: (ScreenDestination) -> Unit
) {
    NavigationBar(
        containerColor = MaterialTheme.colorScheme.surface,
        tonalElevation = 3.dp
    ) {
        NavigationBarItem(
            selected = currentScreen is ScreenDestination.Home,
            onClick = { onNavigate(ScreenDestination.Home) },
            icon = {
                Icon(
                    imageVector = if (currentScreen is ScreenDestination.Home) Icons.Filled.Home else Icons.Outlined.Home,
                    contentDescription = "Notes"
                )
            },
            label = { Text("ملاحظاتي / Notes") },
            modifier = Modifier.testTag("nav_home")
        )

        NavigationBarItem(
            selected = currentScreen is ScreenDestination.Favorites,
            onClick = { onNavigate(ScreenDestination.Favorites) },
            icon = {
                Icon(
                    imageVector = if (currentScreen is ScreenDestination.Favorites) Icons.Filled.Star else Icons.Outlined.StarBorder,
                    contentDescription = "Favorites"
                )
            },
            label = { Text("المفضلة / Starred") },
            modifier = Modifier.testTag("nav_favorites")
        )

        NavigationBarItem(
            selected = currentScreen is ScreenDestination.Templates,
            onClick = { onNavigate(ScreenDestination.Templates) },
            icon = {
                Icon(
                    imageVector = if (currentScreen is ScreenDestination.Templates) Icons.Filled.AutoStories else Icons.Outlined.AutoStories,
                    contentDescription = "Templates"
                )
            },
            label = { Text("القوالب / Templates") },
            modifier = Modifier.testTag("nav_templates")
        )

        NavigationBarItem(
            selected = currentScreen is ScreenDestination.Categories,
            onClick = { onNavigate(ScreenDestination.Categories) },
            icon = {
                Icon(
                    imageVector = if (currentScreen is ScreenDestination.Categories) Icons.Filled.Label else Icons.Outlined.Label,
                    contentDescription = "Tags"
                )
            },
            label = { Text("التصنيفات / Tags") },
            modifier = Modifier.testTag("nav_categories")
        )

        NavigationBarItem(
            selected = currentScreen is ScreenDestination.Settings,
            onClick = { onNavigate(ScreenDestination.Settings) },
            icon = {
                Icon(
                    imageVector = if (currentScreen is ScreenDestination.Settings) Icons.Filled.Settings else Icons.Outlined.Settings,
                    contentDescription = "Settings"
                )
            },
            label = { Text("الإعدادات / Theme") },
            modifier = Modifier.testTag("nav_settings")
        )
    }
}
