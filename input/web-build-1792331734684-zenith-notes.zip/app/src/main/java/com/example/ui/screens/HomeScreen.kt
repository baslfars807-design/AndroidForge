package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.staggeredgrid.LazyVerticalStaggeredGrid
import androidx.compose.foundation.lazy.staggeredgrid.StaggeredGridCells
import androidx.compose.foundation.lazy.staggeredgrid.StaggeredGridItemSpan
import androidx.compose.foundation.lazy.staggeredgrid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.*
import com.example.ui.components.NoteCard
import com.example.viewmodel.NotesViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: NotesViewModel,
    userPreferences: UserPreferences,
    onNoteClick: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val searchQuery by viewModel.searchQuery.collectAsState()
    val searchResults by viewModel.searchResults.collectAsState()
    val activeNotes by viewModel.activeNotes.collectAsState()
    val categories by viewModel.categories.collectAsState()
    val selectedCategoryId by viewModel.selectedCategoryId.collectAsState()

    // Determine displayed notes
    val isSearching = searchQuery.isNotBlank()
    val baseNotes = if (isSearching) searchResults else activeNotes

    val filteredNotes = remember(baseNotes, selectedCategoryId) {
        if (selectedCategoryId == null) {
            baseNotes
        } else {
            baseNotes.filter { it.categoryId == selectedCategoryId }
        }
    }

    val pinnedNotes = remember(filteredNotes) { filteredNotes.filter { it.isPinned } }
    val otherNotes = remember(filteredNotes) { filteredNotes.filter { !it.isPinned } }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        Spacer(modifier = Modifier.height(10.dp))

        // Search Bar
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f),
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 14.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Search,
                    contentDescription = "Search",
                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.width(10.dp))
                TextField(
                    value = searchQuery,
                    onValueChange = { viewModel.onSearchQueryChanged(it) },
                    placeholder = {
                        Text(
                            text = "ابحث في الملاحظات والمهام… / Search notes…",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                        )
                    },
                    singleLine = true,
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = androidx.compose.ui.graphics.Color.Transparent,
                        unfocusedContainerColor = androidx.compose.ui.graphics.Color.Transparent,
                        disabledContainerColor = androidx.compose.ui.graphics.Color.Transparent,
                        focusedIndicatorColor = androidx.compose.ui.graphics.Color.Transparent,
                        unfocusedIndicatorColor = androidx.compose.ui.graphics.Color.Transparent
                    ),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("search_input")
                )
                if (searchQuery.isNotEmpty()) {
                    IconButton(
                        onClick = { viewModel.onSearchQueryChanged("") },
                        modifier = Modifier
                            .size(32.dp)
                            .testTag("clear_search_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Clear search",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Category Filter Chips Row
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            contentPadding = PaddingValues(vertical = 4.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            item {
                FilterChip(
                    selected = selectedCategoryId == null,
                    onClick = { viewModel.onCategoryFilterSelected(null) },
                    label = { Text("الكل / All") },
                    leadingIcon = if (selectedCategoryId == null) {
                        { Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp)) }
                    } else null,
                    modifier = Modifier.testTag("category_chip_all")
                )
            }

            items(categories, key = { it.id }) { cat ->
                FilterChip(
                    selected = selectedCategoryId == cat.id,
                    onClick = { viewModel.onCategoryFilterSelected(cat.id) },
                    label = { Text(cat.name) },
                    leadingIcon = if (selectedCategoryId == cat.id) {
                        { Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp)) }
                    } else null,
                    modifier = Modifier.testTag("category_chip_${cat.id}")
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Empty State or Notes List/Grid
        if (filteredNotes.isEmpty()) {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .fillMaxSize()
                    .padding(bottom = 72.dp)
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center,
                    modifier = Modifier.padding(24.dp)
                ) {
                    Surface(
                        shape = CircleShape,
                        color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f),
                        modifier = Modifier.size(80.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = if (isSearching) Icons.Outlined.SearchOff else Icons.Outlined.NoteAdd,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(38.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = if (isSearching) "لم يتم العثور على نتائج\nNo matching notes found" else "لا توجد ملاحظات بعد\nNo notes yet",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = if (isSearching) "جرب كلمة بحث أخرى أو امسح البحث\nTry a different keyword" else "اضغط على الزر لكتابة أول ملاحظة أو قائمة مهام\nTap + below to create your first note or checklist",
                        style = MaterialTheme.typography.bodyMedium,
                        textAlign = TextAlign.Center,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        } else {
            val isGrid = userPreferences.viewMode == ViewMode.GRID

            if (isGrid) {
                LazyVerticalStaggeredGrid(
                    columns = StaggeredGridCells.Fixed(2),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalItemSpacing = 10.dp,
                    contentPadding = PaddingValues(bottom = 88.dp, top = 4.dp),
                    modifier = Modifier
                        .fillMaxSize()
                        .testTag("notes_grid")
                ) {
                    if (pinnedNotes.isNotEmpty()) {
                        item(span = StaggeredGridItemSpan.FullLine) {
                            SectionHeader(title = "📌 المثبتة / Pinned")
                        }
                        items(pinnedNotes, key = { it.id }) { note ->
                            val cat = categories.firstOrNull { it.id == note.categoryId }
                            val checklist = remember(note.checklistJson) {
                                viewModel.parseChecklist(note.checklistJson)
                            }
                            NoteCard(
                                note = note,
                                category = cat,
                                userPreferences = userPreferences,
                                parsedChecklist = checklist,
                                onClick = { onNoteClick(note.id) },
                                onPinClick = { viewModel.togglePin(note) },
                                onFavoriteClick = { viewModel.toggleFavorite(note) },
                                onDeleteClick = { viewModel.deleteNote(note) },
                                onExportPdfClick = { viewModel.exportNoteAsPdf(context, note, cat, checklist) }
                            )
                        }

                        if (otherNotes.isNotEmpty()) {
                            item(span = StaggeredGridItemSpan.FullLine) {
                                SectionHeader(title = "بقية الملاحظات / Others")
                            }
                        }
                    }

                    items(otherNotes, key = { it.id }) { note ->
                        val cat = categories.firstOrNull { it.id == note.categoryId }
                        val checklist = remember(note.checklistJson) {
                            viewModel.parseChecklist(note.checklistJson)
                        }
                        NoteCard(
                            note = note,
                            category = cat,
                            userPreferences = userPreferences,
                            parsedChecklist = checklist,
                            onClick = { onNoteClick(note.id) },
                            onPinClick = { viewModel.togglePin(note) },
                            onFavoriteClick = { viewModel.toggleFavorite(note) },
                            onDeleteClick = { viewModel.deleteNote(note) },
                            onExportPdfClick = { viewModel.exportNoteAsPdf(context, note, cat, checklist) }
                        )
                    }
                }
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(bottom = 88.dp, top = 4.dp),
                    modifier = Modifier
                        .fillMaxSize()
                        .testTag("notes_list")
                ) {
                    if (pinnedNotes.isNotEmpty()) {
                        item { SectionHeader(title = "📌 المثبتة / Pinned") }
                        items(pinnedNotes, key = { it.id }) { note ->
                            val cat = categories.firstOrNull { it.id == note.categoryId }
                            val checklist = remember(note.checklistJson) {
                                viewModel.parseChecklist(note.checklistJson)
                            }
                            NoteCard(
                                note = note,
                                category = cat,
                                userPreferences = userPreferences,
                                parsedChecklist = checklist,
                                onClick = { onNoteClick(note.id) },
                                onPinClick = { viewModel.togglePin(note) },
                                onFavoriteClick = { viewModel.toggleFavorite(note) },
                                onDeleteClick = { viewModel.deleteNote(note) },
                                onExportPdfClick = { viewModel.exportNoteAsPdf(context, note, cat, checklist) }
                            )
                        }

                        if (otherNotes.isNotEmpty()) {
                            item { SectionHeader(title = "بقية الملاحظات / Others") }
                        }
                    }

                    items(otherNotes, key = { it.id }) { note ->
                        val cat = categories.firstOrNull { it.id == note.categoryId }
                        val checklist = remember(note.checklistJson) {
                            viewModel.parseChecklist(note.checklistJson)
                        }
                        NoteCard(
                            note = note,
                            category = cat,
                            userPreferences = userPreferences,
                            parsedChecklist = checklist,
                            onClick = { onNoteClick(note.id) },
                            onPinClick = { viewModel.togglePin(note) },
                            onFavoriteClick = { viewModel.toggleFavorite(note) },
                            onDeleteClick = { viewModel.deleteNote(note) },
                            onExportPdfClick = { viewModel.exportNoteAsPdf(context, note, cat, checklist) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun SectionHeader(title: String) {
    Text(
        text = title,
        style = MaterialTheme.typography.labelLarge,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(vertical = 6.dp)
    )
}
