package com.example.viewmodel

import android.app.Application
import android.content.Context
import android.speech.tts.TextToSpeech
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.NoteflowApplication
import com.example.model.*
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.Locale

sealed class ScreenDestination {
    object Home : ScreenDestination()
    object Favorites : ScreenDestination()
    object Archive : ScreenDestination()
    object Trash : ScreenDestination()
    object Categories : ScreenDestination()
    object Templates : ScreenDestination()
    object Settings : ScreenDestination()
    data class Editor(val noteId: Long?) : ScreenDestination()
}

@OptIn(FlowPreview::class, ExperimentalCoroutinesApi::class)
class NotesViewModel(application: Application) : AndroidViewModel(application) {
    private val app = application as NoteflowApplication
    private val repository = app.noteRepository
    private val preferenceManager = app.preferenceManager

    // Built-in offline Android Text-to-Speech
    private var androidTts: TextToSpeech? = null
    private var isTtsInitialized = false

    init {
        initAndroidTts()
    }

    private fun initAndroidTts() {
        try {
            androidTts = TextToSpeech(app) { status ->
                if (status == TextToSpeech.SUCCESS) {
                    androidTts?.language = Locale.getDefault()
                    isTtsInitialized = true
                }
            }
        } catch (_: Exception) {
            isTtsInitialized = false
        }
    }

    val userPreferences: StateFlow<UserPreferences> = preferenceManager.userPreferencesFlow
        .stateIn(viewModelScope, SharingStarted.Eagerly, UserPreferences())

    private val _currentScreen = MutableStateFlow<ScreenDestination>(ScreenDestination.Home)
    val currentScreen: StateFlow<ScreenDestination> = _currentScreen.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedCategoryId = MutableStateFlow<Long?>(null)
    val selectedCategoryId: StateFlow<Long?> = _selectedCategoryId.asStateFlow()

    val categories: StateFlow<List<Category>> = repository.allCategories
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val activeNotes: StateFlow<List<Note>> = repository.activeNotes
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val favoriteNotes: StateFlow<List<Note>> = repository.favoriteNotes
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val archivedNotes: StateFlow<List<Note>> = repository.archivedNotes
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val trashNotes: StateFlow<List<Note>> = repository.trashNotes
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Filtered / searched notes
    val searchResults: StateFlow<List<Note>> = _searchQuery
        .debounce(200)
        .flatMapLatest { query ->
            if (query.isBlank()) {
                flowOf(emptyList())
            } else {
                repository.searchNotes(query)
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Transient UI notification / Undo state
    private val _snackbarMessage = MutableSharedFlow<String>()
    val snackbarMessage: SharedFlow<String> = _snackbarMessage.asSharedFlow()

    private var lastDeletedNoteId: Long? = null
    private var autoSaveJob: Job? = null

    fun navigateTo(screen: ScreenDestination) {
        _currentScreen.value = screen
    }

    fun onSearchQueryChanged(query: String) {
        _searchQuery.value = query
    }

    fun onCategoryFilterSelected(categoryId: Long?) {
        _selectedCategoryId.value = if (_selectedCategoryId.value == categoryId) null else categoryId
    }

    fun openNoteEditor(noteId: Long? = null) {
        _currentScreen.value = ScreenDestination.Editor(noteId)
    }

    suspend fun getNote(id: Long): Note? {
        return repository.getNoteById(id)
    }

    fun saveNote(note: Note, onSaved: ((Long) -> Unit)? = null) {
        viewModelScope.launch {
            val id = repository.saveNote(note)
            onSaved?.invoke(id)
        }
    }

    fun autoSaveNoteDebounced(note: Note, onSaved: ((Long) -> Unit)? = null) {
        autoSaveJob?.cancel()
        autoSaveJob = viewModelScope.launch {
            delay(500) // 500ms debounce
            val id = repository.saveNote(note)
            onSaved?.invoke(id)
        }
    }

    fun togglePin(note: Note) {
        viewModelScope.launch {
            repository.togglePin(note.id, note.isPinned)
            val msg = if (!note.isPinned) "Note pinned to top" else "Note unpinned"
            _snackbarMessage.emit(msg)
        }
    }

    fun toggleFavorite(note: Note) {
        viewModelScope.launch {
            repository.toggleFavorite(note.id, note.isFavorite)
            val msg = if (!note.isFavorite) "Added to Favorites" else "Removed from Favorites"
            _snackbarMessage.emit(msg)
        }
    }

    fun toggleArchive(note: Note) {
        viewModelScope.launch {
            repository.toggleArchive(note.id, note.isArchived)
            val msg = if (!note.isArchived) "Note archived" else "Note unarchived"
            _snackbarMessage.emit(msg)
        }
    }

    fun deleteNote(note: Note) {
        viewModelScope.launch {
            lastDeletedNoteId = note.id
            repository.moveToTrash(note.id)
            _snackbarMessage.emit("Note moved to Trash")
        }
    }

    fun undoDelete() {
        val id = lastDeletedNoteId ?: return
        viewModelScope.launch {
            repository.restoreFromTrash(id)
            lastDeletedNoteId = null
            _snackbarMessage.emit("Note restored")
        }
    }

    fun restoreNote(note: Note) {
        viewModelScope.launch {
            repository.restoreFromTrash(note.id)
            _snackbarMessage.emit("Note restored from Trash")
        }
    }

    fun deleteNotePermanently(note: Note) {
        viewModelScope.launch {
            repository.deletePermanently(note.id)
            _snackbarMessage.emit("Note permanently deleted")
        }
    }

    fun emptyTrash() {
        viewModelScope.launch {
            repository.emptyTrash()
            _snackbarMessage.emit("Trash emptied")
        }
    }

    fun saveCategory(name: String, colorHex: String, id: Long = 0) {
        viewModelScope.launch {
            if (name.isNotBlank()) {
                repository.saveCategory(Category(id = id, name = name.trim(), colorHex = colorHex))
                _snackbarMessage.emit("Category saved")
            }
        }
    }

    fun deleteCategory(category: Category) {
        viewModelScope.launch {
            repository.deleteCategory(category.id)
            if (_selectedCategoryId.value == category.id) {
                _selectedCategoryId.value = null
            }
            _snackbarMessage.emit("Category deleted")
        }
    }

    fun createNoteFromTemplate(template: NoteTemplate) {
        viewModelScope.launch {
            val checklistItems = template.checklist.map { text ->
                ChecklistItem(
                    id = java.util.UUID.randomUUID().toString(),
                    text = text,
                    isDone = false
                )
            }
            val newNote = Note(
                title = template.defaultTitle,
                content = template.defaultContent,
                checklistJson = repository.serializeChecklist(checklistItems),
                colorHex = template.defaultColorHex
            )
            val id = repository.saveNote(newNote)
            _snackbarMessage.emit("تم تطبيق القالب بنجاح / Template applied!")
            _currentScreen.value = ScreenDestination.Editor(id)
        }
    }

    fun exportNoteAsPdf(
        context: Context,
        note: Note,
        category: Category? = null,
        checklistItems: List<ChecklistItem> = emptyList()
    ): java.io.File? {
        return try {
            val file = com.example.util.NotePdfExporter.exportNoteToPdf(
                context = context,
                note = note,
                category = category,
                checklistItems = checklistItems
            )
            viewModelScope.launch {
                _snackbarMessage.emit("تم إنشاء ملف PDF بنجاح / PDF Generated!")
            }
            com.example.util.NotePdfExporter.shareOrOpenPdf(context, file, note.title)
            file
        } catch (e: Exception) {
            viewModelScope.launch {
                _snackbarMessage.emit("PDF Export Error: ${e.message}")
            }
            null
        }
    }

    fun readNoteAloud(text: String) {
        viewModelScope.launch {
            if (text.isBlank()) return@launch
            try {
                if (!isTtsInitialized || androidTts == null) {
                    initAndroidTts()
                }
                androidTts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "noteflow_tts")
                _snackbarMessage.emit("قراءة الملاحظة صوتياً / Reading aloud")
            } catch (e: Exception) {
                _snackbarMessage.emit("TTS Error: ${e.message}")
            }
        }
    }

    fun stopSpeech() {
        try {
            androidTts?.stop()
        } catch (_: Exception) {}
    }

    // Appearance Preferences
    fun setThemeMode(mode: ThemeMode) {
        viewModelScope.launch { preferenceManager.setThemeMode(mode) }
    }

    fun setPrimaryColor(color: PrimaryColorTheme) {
        viewModelScope.launch { preferenceManager.setPrimaryColor(color) }
    }

    fun setViewMode(mode: ViewMode) {
        viewModelScope.launch { preferenceManager.setViewMode(mode) }
    }

    fun setFontSize(size: FontSizePreference) {
        viewModelScope.launch { preferenceManager.setFontSize(size) }
    }

    fun setCardDensity(density: CardDensityPreference) {
        viewModelScope.launch { preferenceManager.setCardDensity(density) }
    }

    // Backup & Restore
    suspend fun exportBackupJson(): String {
        return repository.createBackupJson()
    }

    suspend fun importBackupJson(json: String): Result<Int> {
        val result = repository.restoreBackupJson(json)
        result.onSuccess { count ->
            _snackbarMessage.emit("Successfully imported $count notes!")
        }.onFailure { err ->
            _snackbarMessage.emit("Import failed: ${err.message}")
        }
        return result
    }

    fun formatNoteAsText(note: Note): String {
        return repository.formatNoteAsText(note)
    }

    fun parseChecklist(json: String?): List<ChecklistItem> = repository.parseChecklist(json)
    fun serializeChecklist(items: List<ChecklistItem>): String = repository.serializeChecklist(items)

    override fun onCleared() {
        super.onCleared()
        try {
            androidTts?.stop()
            androidTts?.shutdown()
        } catch (_: Exception) {}
    }
}
