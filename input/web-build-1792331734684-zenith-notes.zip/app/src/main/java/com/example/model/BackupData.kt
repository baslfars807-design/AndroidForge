package com.example.model

import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class BackupData(
    val version: Int = 1,
    val exportDate: Long = System.currentTimeMillis(),
    val app: String = "Noteflow",
    val notes: List<Note> = emptyList(),
    val categories: List<Category> = emptyList()
)
