package com.example

import com.example.model.BackupData
import com.example.model.Category
import com.example.model.ChecklistItem
import com.example.model.Note
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import org.junit.Assert.*
import org.junit.Test

class ExampleUnitTest {
    private val moshi = Moshi.Builder().addLast(KotlinJsonAdapterFactory()).build()

    @Test
    fun testChecklistSerializationAndParsing() {
        val type = Types.newParameterizedType(List::class.java, ChecklistItem::class.java)
        val adapter = moshi.adapter<List<ChecklistItem>>(type)

        val items = listOf(
            ChecklistItem(id = "1", text = "Buy groceries", isDone = false),
            ChecklistItem(id = "2", text = "Call plumber", isDone = true)
        )

        val json = adapter.toJson(items)
        assertNotNull(json)
        assertTrue(json.contains("Buy groceries"))
        assertTrue(json.contains("Call plumber"))

        val parsed = adapter.fromJson(json)
        assertNotNull(parsed)
        assertEquals(2, parsed?.size)
        assertEquals("Buy groceries", parsed?.get(0)?.text)
        assertFalse(parsed?.get(0)?.isDone ?: true)
        assertTrue(parsed?.get(1)?.isDone ?: false)
    }

    @Test
    fun testBackupDataSerialization() {
        val adapter = moshi.adapter(BackupData::class.java)

        val backup = BackupData(
            version = 1,
            app = "Noteflow",
            notes = listOf(
                Note(id = 1, title = "Important Note", content = "Don't forget the keys", isPinned = true)
            ),
            categories = listOf(
                Category(id = 1, name = "Personal", colorHex = "#6366F1")
            )
        )

        val json = adapter.toJson(backup)
        assertTrue(json.contains("Important Note"))
        assertTrue(json.contains("Personal"))

        val restored = adapter.fromJson(json)
        assertNotNull(restored)
        assertEquals(1, restored?.notes?.size)
        assertEquals("Important Note", restored?.notes?.firstOrNull()?.title)
        assertTrue(restored?.notes?.firstOrNull()?.isPinned ?: false)
    }

    @Test
    fun testInvalidBackupHandling() {
        val adapter = moshi.adapter(BackupData::class.java)
        val invalidJson = "{ invalid json data }"
        var failed = false
        try {
            adapter.fromJson(invalidJson)
        } catch (_: Exception) {
            failed = true
        }
        assertTrue("Invalid JSON must throw exception", failed)
    }

    @Test
    fun testNoteTemplates() {
        val templates = com.example.model.NoteTemplates.list
        assertTrue(templates.isNotEmpty())
        val meetingTemplate = templates.find { it.id == "meeting" }
        assertNotNull(meetingTemplate)
        assertTrue(meetingTemplate!!.checklist.isNotEmpty())
    }
}
