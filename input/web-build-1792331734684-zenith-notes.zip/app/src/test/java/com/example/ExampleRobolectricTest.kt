package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.AppDatabase
import com.example.data.repository.NoteRepository
import com.example.model.Category
import com.example.model.Note
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    private lateinit var database: AppDatabase
    private lateinit var repository: NoteRepository

    @Before
    fun setup() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        database = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        repository = NoteRepository(database.noteDao(), database.categoryDao())
    }

    @After
    fun tearDown() {
        database.close()
    }

    @Test
    fun testAppNameString() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Noteflow", appName)
    }

    @Test
    fun testInsertAndRetrieveNote() = runBlocking {
        val note = Note(title = "Shopping List", content = "Milk, Bread, Eggs")
        val id = repository.saveNote(note)
        assertTrue(id > 0)

        val retrieved = repository.getNoteById(id)
        assertNotNull(retrieved)
        assertEquals("Shopping List", retrieved?.title)
        assertEquals("Milk, Bread, Eggs", retrieved?.content)
    }

    @Test
    fun testEditExistingNote() = runBlocking {
        val initial = Note(title = "Original Title", content = "Original Content")
        val id = repository.saveNote(initial)

        val retrieved = repository.getNoteById(id)
        assertNotNull(retrieved)

        val updated = retrieved!!.copy(title = "Updated Title", content = "Updated Content")
        repository.saveNote(updated)

        val reloaded = repository.getNoteById(id)
        assertEquals("Updated Title", reloaded?.title)
        assertEquals("Updated Content", reloaded?.content)
    }

    @Test
    fun testPinAndUnpinNote() = runBlocking {
        val note = Note(title = "Pin Test", content = "Testing pinning")
        val id = repository.saveNote(note)

        repository.togglePin(id, currentPinned = false)
        val pinned = repository.getNoteById(id)
        assertTrue(pinned?.isPinned ?: false)

        repository.togglePin(id, currentPinned = true)
        val unpinned = repository.getNoteById(id)
        assertFalse(unpinned?.isPinned ?: true)
    }

    @Test
    fun testFavoriteNote() = runBlocking {
        val note = Note(title = "Fav Test", content = "Testing favorite")
        val id = repository.saveNote(note)

        repository.toggleFavorite(id, currentFavorite = false)
        val favorited = repository.getNoteById(id)
        assertTrue(favorited?.isFavorite ?: false)

        repository.toggleFavorite(id, currentFavorite = true)
        val unfavorited = repository.getNoteById(id)
        assertFalse(unfavorited?.isFavorite ?: true)
    }

    @Test
    fun testTrashAndRestore() = runBlocking {
        val note = Note(title = "To be deleted", content = "Delete me")
        val id = repository.saveNote(note)

        repository.moveToTrash(id)
        val inTrash = repository.getNoteById(id)
        assertTrue(inTrash?.isDeleted ?: false)

        val activeList = repository.activeNotes.first()
        assertFalse(activeList.any { it.id == id })

        val trashList = repository.trashNotes.first()
        assertTrue(trashList.any { it.id == id })

        // Restore
        repository.restoreFromTrash(id)
        val restored = repository.getNoteById(id)
        assertFalse(restored?.isDeleted ?: true)

        val activeListAfter = repository.activeNotes.first()
        assertTrue(activeListAfter.any { it.id == id })
    }

    @Test
    fun testSearchNotes() = runBlocking {
        val note1 = Note(title = "Android Architecture", content = "MVVM with Jetpack Compose")
        val note2 = Note(title = "Cooking Recipe", content = "Pasta carbonara")
        repository.saveNote(note1)
        repository.saveNote(note2)

        val searchResult1 = repository.searchNotes("Architecture").first()
        assertEquals(1, searchResult1.size)
        assertEquals("Android Architecture", searchResult1.first().title)

        val searchResult2 = repository.searchNotes("carbonara").first()
        assertEquals(1, searchResult2.size)
        assertEquals("Cooking Recipe", searchResult2.first().title)
    }

    @Test
    fun testCategoryOperations() = runBlocking {
        val category = Category(name = "Work", colorHex = "#0D9488")
        val catId = repository.saveCategory(category)
        assertTrue(catId > 0)

        val allCategories = repository.allCategories.first()
        assertTrue(allCategories.any { it.name == "Work" })

        repository.deleteCategory(catId)
        val afterDelete = repository.allCategories.first()
        assertFalse(afterDelete.any { it.id == catId })
    }

    @Test
    fun testBackupAndRestoreWorkflow() = runBlocking {
        val note = Note(title = "Backup Item", content = "Save to JSON")
        val cat = Category(name = "Important", colorHex = "#E11D48")
        repository.saveNote(note)
        repository.saveCategory(cat)

        val backupJson = repository.createBackupJson()
        assertTrue(backupJson.contains("Backup Item"))
        assertTrue(backupJson.contains("Important"))

        // Simulate restore into fresh DB
        val context = ApplicationProvider.getApplicationContext<Context>()
        val newDb = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java).allowMainThreadQueries().build()
        val newRepo = NoteRepository(newDb.noteDao(), newDb.categoryDao())

        val result = newRepo.restoreBackupJson(backupJson)
        assertTrue(result.isSuccess)

        val restoredNotes = newRepo.activeNotes.first()
        assertTrue(restoredNotes.any { it.title == "Backup Item" })
        newDb.close()
    }

    @Test
    fun testExportNoteToPdf() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val testNote = Note(
            id = 42,
            title = "Quarterly Business Review",
            content = "Summary of Q3 results and milestones.\nRevenue targets exceeded by 14%."
        )
        val testCategory = Category(name = "Business", colorHex = "#4F46E5")
        val checklist = listOf(
            com.example.model.ChecklistItem(id = "1", text = "Send summary to stakeholders", isDone = true),
            com.example.model.ChecklistItem(id = "2", text = "Schedule follow-up meeting", isDone = false)
        )

        val pdfFile = com.example.util.NotePdfExporter.exportNoteToPdf(
            context = context,
            note = testNote,
            category = testCategory,
            checklistItems = checklist
        )

        assertNotNull(pdfFile)
        assertTrue(pdfFile.exists())
        assertTrue("PDF file should have content", pdfFile.length() > 0)

        // Verify PDF Header signature (%PDF)
        val headerBytes = ByteArray(4)
        pdfFile.inputStream().use { it.read(headerBytes) }
        val headerString = String(headerBytes)
        assertEquals("%PDF", headerString)
    }
}
