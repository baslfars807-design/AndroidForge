plugins { id("com.android.application"); id("org.jetbrains.kotlin.android"); id("dev.flutter.flutter-gradle-plugin") }
android { namespace = "com.taskflow.app"; compileSdk = flutter.compileSdkVersion; ndkVersion = flutter.ndkVersion
  compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
  kotlinOptions { jvmTarget = JavaVersion.VERSION_17.toString() }
  defaultConfig { applicationId = "com.taskflow.app"; minSdk = 28; targetSdk = flutter.targetSdkVersion; versionCode = flutter.versionCode; versionName = flutter.versionName }
}
flutter { source = "../.." }
